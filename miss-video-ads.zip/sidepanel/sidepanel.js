// sidepanel.js — Chat logic controller for Nova 2.0 Co-Pilot Panel (Gemini & ChatGPT support)

document.addEventListener("DOMContentLoaded", async () => {
  // DOM Elements
  const cw = document.getElementById("cw");
  const uin = document.getElementById("uin");
  const sbtn = document.getElementById("sbtn");
  const qtags = document.getElementById("qtags");
  const prog = document.getElementById("prog");

  // Marketing Framework Blueprints
  const FW_DETAILS = {
    PAS: {
      name: 'PAS (Problem - Agitate - Solve)',
      code: 'PAS',
      desc: '<strong>Xoáy sâu nỗi đau -> Đưa giải pháp.</strong><br>Cách hoạt động: Chỉ thẳng vào vấn đề bức bối -> Mô tả chi tiết hậu quả để kích động cảm xúc -> Đưa sản phẩm ra như cứu cánh duy nhất. Cực kỳ tối ưu cho hàng tiêu dùng nhanh, mỹ phẩm, thời trang, sản phẩm vật lý.'
    },
    AIDA: {
      name: 'AIDA (Attention - Interest - Desire - Action)',
      code: 'AIDA',
      desc: '<strong>Gây chú ý -> Thích thú -> Khao khát -> Hành động.</strong><br>Cách hoạt động: Thu hút 3s đầu -> Cung cấp thông tin lôi cuốn xây dựng lòng tin -> Đưa ra ưu đãi kích thích khao khát sở hữu -> Kêu gọi hành động dứt khoát. Phù hợp nhất cho khóa học, dịch vụ chuyên gia, sản phẩm giá trị cao.'
    },
    HRR: {
      name: 'HRR (Hook - Retain - Reward)',
      code: 'HRR',
      desc: '<strong>Gây tò mò -> Giữ chân -> Phần thưởng bất ngờ.</strong><br>Cách hoạt động: Móc người xem bằng câu hỏi ngược định kiến -> Dẫn dắt nhịp độ kịch tính kể chuyện giữ chân -> Tặng quà/kết quả bất ngờ ở cuối. Tối ưu cho xây kênh viral giải trí, phát triển thương hiệu cá nhân.'
    }
  };

  // State Management
  let step = 0;
  let busy = false;
  let waitingToOpen = false;
  let selectedFramework = null;

  let userData = {
    industry: "",
    framework: "",
    fwCode: ""
  };

  // 1. CHUNK TYPEWRITER ANIMATION
  function chunk(el, html, n = 3, ms = 12) {
    return new Promise((resolve) => {
      el.innerHTML = '';
      const tokens = [];
      const re = /(<[^>]+>|&[^;]+;|[\s\S])/g;
      let m;
      while ((m = re.exec(html)) !== null) tokens.push(m[0]);
      
      let i = 0;
      const CUR = '<span class="cur"></span>';
      
      function tick() {
        if (i >= tokens.length) {
          el.innerHTML = html;
          resolve();
          return;
        }
        let added = 0;
        while (i < tokens.length && added < n) {
          i++;
          if (!tokens[i - 1].startsWith('<')) added++;
        }
        el.innerHTML = tokens.slice(0, i).join('') + CUR;
        scrollB();
        const last = tokens[i - 1] || '';
        const delay = last === '.' || last === '!' || last === '?' ? 120 : last === ',' ? 60 : ms;
        setTimeout(tick, delay);
      }
      tick();
    });
  }

  // 2. CHAT BUILDERS
  async function novaSay(html) {
    busy = true;
    toggleInput(false);
    
    const row = document.createElement('div');
    row.className = 'msg';
    const geminiGradId = 'gem-g-' + Math.random().toString(36).substr(2, 9);
    row.innerHTML = `
      <div class="mav nova">
        <svg viewBox="0 0 24 24" width="20" height="20" style="display: block;">
          <defs>
            <linearGradient id="${geminiGradId}" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#9b72cb" />
              <stop offset="50%" stop-color="#d96570" />
              <stop offset="100%" stop-color="#f4b400" />
            </linearGradient>
          </defs>
          <path d="M12 2a1 1 0 0 1 1 1v6a3 3 0 0 0 3 3h6a1 1 0 0 1 0 2h-6a3 3 0 0 0-3 3v6a1 1 0 0 1-2 0v-6a3 3 0 0 0-3-3H3a1 1 0 0 1 0-2h6a3 3 0 0 0 3-3V3a1 1 0 0 1 1-1z" fill="url(#${geminiGradId})" />
        </svg>
      </div>
      <div class="bubble"><div class="txt"></div>
      <div class="bm"><svg viewBox="0 0 24 24" width="10" height="10" fill="var(--primary-color)" style="margin-right:2px"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg> ${getNowTime()}</div></div>`;
    
    const txt = row.querySelector('.txt');
    cw.appendChild(row);
    scrollB();
    
    await chunk(txt, html, 3, 10);
    busy = false;
    toggleInput(true);
  }

  function userSay(text) {
    const row = document.createElement('div');
    row.className = 'msg user';
    row.innerHTML = `
      <div class="mav human"><svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor" style="display: block;"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg></div>
      <div class="bubble"><div class="txt"></div>
      <div class="bm"><svg viewBox="0 0 24 24" width="10" height="10" fill="#555" style="margin-right:2px"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg> ${getNowTime()}</div></div>`;
    
    row.querySelector('.txt').textContent = text;
    cw.appendChild(row);
    scrollB();
  }

  // 3. BOOTSTRAP INITIAL QUESTION (Generic Suggestions)
  async function askQ1() {
    await novaSay(
      'Chào bạn! Tôi là <span class="h">Miss Video Ads</span> — trợ lý sáng tạo kịch bản video quảng cáo.<br><br>' +
      'Đầu tiên, hãy nhập thông tin về <span class="h">sản phẩm hoặc dịch vụ</span> của bạn.<br><br>' +
      '💡 <em>Mẹo: Hãy viết mô tả càng chi tiết càng tốt (Ví dụ: tính năng nổi bật, đối tượng khách hàng mục tiêu, vấn đề giải quyết,...). Mô tả càng chi tiết thì kịch bản của bạn sẽ càng sâu sắc và thực chiến!</em>'
    );
    clearTags(); // Gỡ bỏ hoàn toàn các thẻ mớm ý để người dùng tự nhập sâu hơn
    uin.focus();
  }

  // 4. ACTION PROCESSOR
  async function send() {
    const val = uin.value.trim();
    if (!val || busy) return;

    userSay(val);
    uin.value = '';
    clearTags();
    toggleInput(false);

    await sleep(400);

    // SUB-STATE: WAITING FOR TAB TO BE OPENED
    if (waitingToOpen) {
      if (val === "Gửi kịch bản ngay") {
        await executePromptLaunch();
      } else if (val.includes("ChatGPT")) {
        await chrome.tabs.create({ url: 'https://chatgpt.com' });
        await novaSay("Tôi đã mở tab ChatGPT mới. Đợi trang tải hoàn tất, hãy bấm nút <strong>'Gửi kịch bản ngay'</strong> ở dưới để chạy.");
        renderTags(["Gửi kịch bản ngay"]);
      } else if (val.includes("Gemini")) {
        await chrome.tabs.create({ url: 'https://gemini.google.com' });
        await novaSay("Tôi đã mở tab Gemini mới. Đợi trang tải hoàn tất, hãy bấm nút <strong>'Gửi kịch bản ngay'</strong> ở dưới để chạy.");
        renderTags(["Gửi kịch bản ngay"]);
      }
      return;
    }

    // STATE 0: PRODUCT SUBMITTED -> RENDER EDUCATIONAL FRAMEWORKS
    if (step === 0) {
      userData.industry = val;
      setProgress(1, 2);

      await novaSay(`Ngành hàng <strong>"${val}"</strong> đã được tiếp nhận.`);
      await sleep(300);

      // Display the 3 frameworks like a dynamic tutorial/teacher
      await novaSay(
        `Dưới đây là 3 mô hình marketing kịch bản tối ưu nhất. Hãy đọc kỹ nguyên lý của từng mô hình và <strong>bấm chọn 1 mô hình để khởi chạy trực tiếp sang AI</strong>:<br><br>` +
        
        `<div class="fw-card" style="border-left: 3px solid #3b82f6;">` +
        `<div class="fw-title"><span class="brand-badge">Mô hình 1</span> PAS</div>` +
        `<div class="fw-name">${FW_DETAILS.PAS.name}</div>` +
        `<div class="fw-desc">${FW_DETAILS.PAS.desc}</div>` +
        `</div>` +

        `<div class="fw-card" style="border-left: 3px solid #6366f1;">` +
        `<div class="fw-title"><span class="brand-badge">Mô hình 2</span> AIDA</div>` +
        `<div class="fw-name">${FW_DETAILS.AIDA.name}</div>` +
        `<div class="fw-desc">${FW_DETAILS.AIDA.desc}</div>` +
        `</div>` +

        `<div class="fw-card" style="border-left: 3px solid #10b981;">` +
        `<div class="fw-title"><span class="brand-badge">Mô hình 3</span> HRR</div>` +
        `<div class="fw-name">${FW_DETAILS.HRR.name}</div>` +
        `<div class="fw-desc">${FW_DETAILS.HRR.desc}</div>` +
        `</div>`
      );
      await sleep(400);

      step = 1;
      renderTags([
        'Áp dụng mô hình PAS',
        'Áp dụng mô hình AIDA',
        'Áp dụng mô hình HRR'
      ]);
      uin.placeholder = "Bấm chọn mô hình ở trên...";
      toggleInput(false); // disable input text to force clicking tag button

    } else if (step === 1) {
      // USER SELECTED A FRAMEWORK -> AUTO LAUNCH DIRECTLY
      let code = "PAS";
      if (val.includes("AIDA")) code = "AIDA";
      else if (val.includes("HRR")) code = "HRR";

      selectedFramework = FW_DETAILS[code];
      userData.framework = selectedFramework.name;
      userData.fwCode = selectedFramework.code;

      await executePromptLaunch();
    }
  }

  // 5. AUTO-INJECTION AND IMMEDIATE LAUNCH
  async function executePromptLaunch() {
    setProgress(2, 2);
    toggleInput(false);
    
    await novaSay(`Đã chọn công thức <strong class="h">${selectedFramework.code}</strong>. Đang thiết lập kết nối và nạp kịch bản chiến lược sang trang AI...`);
    await sleep(350);

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    // Check if user is currently on a supported tab
    const isSupported = tab && tab.url && (tab.url.includes("gemini.google.com") || tab.url.includes("chatgpt.com"));
    
    if (!isSupported) {
      // If not on ChatGPT or Gemini, offer to open them
      await novaSay(
        `Không tìm thấy tab ChatGPT hoặc Gemini đang mở ở cửa sổ trình duyệt hiện tại.<br><br>` +
        `Vui lòng chọn nền tảng bạn muốn chạy kịch bản dưới đây để tôi mở tab mới:`
      );
      waitingToOpen = true;
      renderTags([
        "Mở và gửi sang ChatGPT",
        "Mở và gửi sang Gemini"
      ]);
      return;
    }

    waitingToOpen = false;
    const isChatGPT = tab.url.includes("chatgpt.com");
    const aiName = isChatGPT ? "ChatGPT" : "Gemini";

    // Auto-inject and auto-send
    try {
      // Inject content.js on-demand
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["content.js"]
      });

      const promptText = buildPrompt();

      // Send instruction safely to catch any lastError
      const response = await new Promise((resolve) => {
        chrome.tabs.sendMessage(tab.id, {
          action: "INJECT_PROMPT",
          prompt: promptText
        }, (res) => {
          const err = chrome.runtime.lastError;
          if (err) {
            resolve({ success: false, error: err.message });
          } else {
            resolve(res);
          }
        });
      });

      if (response && response.success) {
        showToast("✓ Khởi chạy kịch bản thành công!");
        await sleep(350); // Delay ngắn để hiển thị toast
        window.close();   // Tự động đóng Side Panel ngay lập tức!
      } else {
        throw new Error(response ? response.error : "Không nhận được phản hồi nạp dữ liệu.");
      }
    } catch (err) {
      console.error(err);
      // FAILURE FALLBACK: Render prompt box + copy + retry buttons only when error happens!
      await renderFallbackPromptBox(err.message);
    }
  }

  // 6. RENDER FALLBACK PROMPT BOX (Only called on failure to prevent blocking the user)
  async function renderFallbackPromptBox(errorMsg) {
    await novaSay(
      `<span style="color:#f28b82;"><svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor" style="display:inline-block; vertical-align:middle; margin-right:4px;"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg> Gặp sự cố kết nối tự động:</span> ${errorMsg}.<br><br>` +
      `Đã chuyển sang chế độ nạp thủ công. Bạn có thể nhấn nút gửi lại dưới đây hoặc sử dụng nút **Sao chép** để dán kịch bản vào AI:`
    );

    const promptText = buildPrompt();
    const pid = 'pr_' + Date.now();

    const row = document.createElement('div');
    row.className = 'msg';
    const geminiGradPromptId = 'gem-g-p-' + Math.random().toString(36).substr(2, 9);
    row.innerHTML = `
      <div class="mav nova">
        <svg viewBox="0 0 24 24" width="20" height="20" style="display: block;">
          <defs>
            <linearGradient id="${geminiGradPromptId}" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#9b72cb" />
              <stop offset="50%" stop-color="#d96570" />
              <stop offset="100%" stop-color="#f4b400" />
            </linearGradient>
          </defs>
          <path d="M12 2a1 1 0 0 1 1 1v6a3 3 0 0 0 3 3h6a1 1 0 0 1 0 2h-6a3 3 0 0 0-3 3v6a1 1 0 0 1-2 0v-6a3 3 0 0 0-3-3H3a1 1 0 0 1 0-2h6a3 3 0 0 0 3-3V3a1 1 0 0 1 1-1z" fill="url(#${geminiGradPromptId})" />
        </svg>
      </div>
      <div class="bubble" style="max-width:100%; border-color: rgba(239, 68, 68, 0.3)">
        <div style="font-size:11px;color:var(--text-dim);margin-bottom:6px">Meta-Prompt kịch bản của bạn:</div>
        <div class="pbox" id="${pid}"><button class="cpbtn">Sao chép</button>${escapeHtml(promptText)}</div>
        <div class="btn-row" style="flex-direction: column; gap: 8px;">
          <button class="open-ai-btn" id="btn-send-chatgpt" style="background: linear-gradient(135deg, #10a37f, #0d7f62); box-shadow: 0 4px 10px rgba(16, 163, 127, 0.2);">
            <svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor" style="margin-right:4px; display:inline-block; vertical-align:middle;"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg> Gửi lại sang ChatGPT
          </button>
          <button class="open-ai-btn gemini" id="btn-send-gemini">
            <svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor" style="margin-right:4px; display:inline-block; vertical-align:middle;"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg> Gửi lại sang Gemini
          </button>
        </div>
      </div>`;

    // Bind Copy Button
    const cpBtn = row.querySelector('.cpbtn');
    cpBtn.onclick = () => copyText(promptText);

    // Bind Send Buttons
    const btnChatGPT = row.querySelector('#btn-send-chatgpt');
    const btnGemini = row.querySelector('#btn-send-gemini');

    btnChatGPT.onclick = async () => {
      await handleSendAction("chatgpt.com", btnChatGPT, promptText);
    };

    btnGemini.onclick = async () => {
      await handleSendAction("gemini.google.com", btnGemini, promptText);
    };

    cw.appendChild(row);
    scrollB();

    // Reset button creation
    clearTags();
    const rb = document.createElement('button');
    rb.className = 'qt';
    rb.innerHTML = '<svg viewBox="0 0 24 24" width="10" height="10" fill="currentColor" style="margin-right:4px"><path d="M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z"/></svg> Tạo kịch bản mới';
    rb.onclick = () => {
      window.location.reload();
    };
    qtags.appendChild(rb);
  }

  // 7. ACTION SEND HANDLER (Always accessible, retry-friendly)
  async function handleSendAction(domain, button, promptText) {
    const originalContent = button.innerHTML;
    button.disabled = true;
    button.textContent = "Đang kết nối...";

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const matchesDomain = tab && tab.url && tab.url.includes(domain);

    if (!matchesDomain) {
      // Open new tab
      const platformName = domain.includes("chatgpt") ? "ChatGPT" : "Gemini";
      const targetUrl = domain.includes("chatgpt") ? "https://chatgpt.com" : "https://gemini.google.com";
      
      await novaSay(
        `Bạn cần mở tab <strong class="h">${platformName}</strong> để gửi kịch bản.<br><br>` +
        `Tôi đang tự động mở tab mới giúp bạn. Sau khi trang tải xong, hãy nhấn lại nút <strong>"Gửi lại sang ${platformName}"</strong> ở bảng điều khiển của Miss Video Ads để chạy.`
      );
      
      await chrome.tabs.create({ url: targetUrl });
      
      button.disabled = false;
      button.innerHTML = originalContent;
      return;
    }

    try {
      // Inject content.js on-demand
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["content.js"]
      });

      // Send injection command safely to catch any lastError
      const response = await new Promise((resolve) => {
        chrome.tabs.sendMessage(tab.id, {
          action: "INJECT_PROMPT",
          prompt: promptText
        }, (res) => {
          const err = chrome.runtime.lastError;
          if (err) {
            resolve({ success: false, error: err.message });
          } else {
            resolve(res);
          }
        });
      });

      if (response && response.success) {
        // Show status bar
        const statusBar = document.getElementById("status-bar");
        const statusText = document.getElementById("status-text");
        if (statusBar && statusText) {
          statusBar.style.display = "flex";
          statusText.innerHTML = "Đang đồng bộ cuộc trò chuyện...";
        }

        showToast("✓ Đã nạp và gửi prompt tự động!");
        button.disabled = false;
        button.innerHTML = `✓ Đã nạp thành công (${domain.includes("chatgpt") ? "ChatGPT" : "Gemini"})`;
        button.style.background = "linear-gradient(135deg, #10b981, #059669)";
        
        await novaSay(`Đã gửi kịch bản thành công sang <strong>${domain.includes("chatgpt") ? "ChatGPT" : "Gemini"}</strong> bên trái! Bạn có thể bắt đầu thảo luận.`);
      } else {
        throw new Error(response ? response.error : "Không nhận được phản hồi nạp dữ liệu.");
      }
    } catch (e) {
      console.error(e);
      await novaSay(`Lỗi gửi tự động: ${e.message}. Bạn hãy kiểm tra lại tab bên cạnh hoặc sử dụng nút <strong>"Sao chép"</strong> để dán thủ công.`);
      button.disabled = false;
      button.innerHTML = originalContent;
    }
  }

  function buildPrompt() {
    // 1. Random name selection to break static patterns
    const NAMES = ["Leo", "Alex", "Zoe", "Victor", "Kira", "David", "Sophia", "Mark", "Elena"];
    const name = NAMES[Math.floor(Math.random() * NAMES.length)];
    
    // 2. Random Tone Styles
    const TONE_STYLES = [
      { name: 'Đanh thép & Thực chiến', desc: 'đi thẳng vào vấn đề, sử dụng các động từ mạnh mẽ, nhịp độ nhanh và dứt khoát' },
      { name: 'Cuốn hút & Bắt trend', desc: 'ngôn từ hiện đại, trẻ trung, bắt nhịp nhanh với thị hiếu người xem video ngắn hiện nay' },
      { name: 'Thuyết phục & Chiều sâu', desc: 'tập trung vào giá trị cốt lõi, lập luận chặt chẽ, tạo niềm tin lớn bằng ngôn ngữ chuyên gia' },
      { name: 'Hài hước & Châm biếm nhẹ', desc: 'sử dụng phép so sánh phóng đại hóm hỉnh để tạo sự thích thú và bất ngờ cho người xem' },
      { name: 'Kể chuyện & Gợi mở cảm xúc', desc: 'phong cách storytelling, tạo sự đồng cảm sâu sắc với nỗi đau trước khi giới thiệu giải pháp' }
    ];
    const chosenTone = TONE_STYLES[Math.floor(Math.random() * TONE_STYLES.length)];
    
    // 3. Random Separators
    const DIVIDERS = [
      '═══════════════════════════════════════════',
      '───────────────────────────────────────────',
      '❖❖❖❖❖❖❖❖❖❖❖❖❖❖❖❖❖❖❖❖❖❖❖❖❖❖❖❖❖❖❖❖❖❖❖❖❖❖❖❖❖❖❖',
      '◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆'
    ];
    const div = DIVIDERS[Math.floor(Math.random() * DIVIDERS.length)];
    
    // 4. Random Bullets
    const BULLETS = [
      { main: '▸', sub: '▪', arrow: '=>' },
      { main: '✦', sub: '▫', arrow: '→' },
      { main: '❖', sub: '•', arrow: '->' }
    ];
    const bul = BULLETS[Math.floor(Math.random() * BULLETS.length)];
    
    // 5. Random Intro Phrasing
    const INTRUS = [
      `Bạn là ${name} — Giám đốc Sáng tạo kiêm Chuyên gia biên kịch Video Quảng cáo chuyển đổi (Conversion Ad Video Director).`,
      `Hãy đóng vai trò là ${name} — Senior Copywriter kiêm Creative Director chuyên trách video ngắn thương mại dưới 60s.`,
      `Nhập vai ${name} — Chuyên gia sản xuất kịch bản TikTok Ads & Reels chuyển đổi cao.`,
      `Bạn sẽ đóng vai ${name} — Chiến lược gia nội dung thực chiến, chuyên gia sản xuất kịch bản viral video ngắn.`
    ];
    const chosenIntro = INTRUS[Math.floor(Math.random() * INTRUS.length)];

    // 6. Random Outro Phrasing (how to start BƯỚC 2)
    const OUTROS = [
      `Bây giờ, bạn hãy bỏ qua Bước 1, ghi nhận dữ liệu ban đầu, và trực tiếp bắt đầu BƯỚC 2 bằng cách đặt Câu hỏi 4 kèm các gợi ý phương án A, B, C, D thực tế cho sản phẩm "${userData.industry}" của tôi!`,
      `Hãy ghi nhận dữ liệu ban đầu và khởi động ngay BƯỚC 2. Hãy hỏi tôi Câu hỏi 4 về USP của sản phẩm "${userData.industry}". Nhớ đề xuất các gợi ý phương án lựa chọn A, B, C, D thật thông minh và thực tế nhé!`,
      `Ghi nhớ thông tin sản phẩm "${userData.industry}" và công thức ${userData.fwCode}. Hãy bắt đầu ngay cuộc phỏng vấn ở BƯỚC 2 bằng việc đặt Câu hỏi 4. Đừng quên đưa ra các gợi ý A, B, C, D được thiết kế riêng cho ngách sản phẩm này.`
    ];
    const chosenOutro = OUTROS[Math.floor(Math.random() * OUTROS.length)];

    return `${chosenIntro} 
Nhiệm vụ của bạn là đồng hành thiết kế kịch bản video ngắn (dưới 60 giây, tối đa 200 từ) có tỷ lệ chuyển đổi cao. 

Quy trình làm việc của chúng ta gồm 6 bước tương tác tuyến tính. Hãy tuân thủ nghiêm ngặt quy tắc: "Chỉ hiển thị nội dung của bước hiện tại, tuyệt đối không hiển thị trước câu hỏi hay nội dung của bước sau. Mỗi lần chỉ hỏi 1 câu hỏi duy nhất và chờ phản hồi".

Quy tắc hành xử tự nhiên (Quan trọng): Khi tương tác, hãy trò chuyện với tôi bằng phong cách của một đồng nghiệp/đối tác thân thiện và lịch lãm. Tránh việc liệt kê máy móc hoặc chép nguyên văn các tiêu đề cứng nhắc (ví dụ như "BƯỚC 2: KHAI THÁC USP"), hãy lồng ghép câu hỏi và các phương án gợi ý một cách tự nhiên nhất để tạo cảm giác thảo luận thật.

${div}
QUY TRÌNH HỘI THOẠI 6 BƯỚC (BẮT ĐẦU TỪ BƯỚC 2)
${div}

${bul.main} BƯỚC 1: THU THẬP DỮ LIỆU BAN ĐẦU (ĐÃ HOÀN THÀNH)
Sản phẩm/dịch vụ của tôi là "${userData.industry}" và công thức tôi muốn sử dụng là ${userData.framework} [${userData.fwCode}]. Bạn hãy ghi nhận dữ liệu này và tuyệt đối không hỏi lại. Hãy trực tiếp bắt đầu cuộc trò chuyện từ BƯỚC 2 dưới đây.

${bul.main} BƯỚC 2: KHAI THÁC USP (AI đặt Câu hỏi 4)
### 💡 BƯỚC 2: KHAI THÁC LỢI THẾ CẠNH TRANH (USP)

> 📌 **TƯ DUY THỰC CHIẾN: Tại sao cần xác định USP của sản phẩm?**
> USP (Unique Selling Proposition) là lý do khách hàng chọn mua sản phẩm của bạn thay vì đối thủ. Một kịch bản quảng cáo mạnh mẽ phải xoay quanh điểm cốt lõi này để thuyết phục khách hàng.

---

#### ❓ CÂU HỎI 4:
* **Lợi thế cạnh tranh lớn nhất (USP) hoặc điểm khác biệt của sản phẩm "${userData.industry}" này là gì?**

---

#### 💡 PHAO CỨU SINH (GỢI Ý TỪ TRỢ LÝ):
* **[A]** [AI tự gợi ý mẫu dựa trên sản phẩm]
* **[B]** [AI tự gợi ý mẫu dựa trên sản phẩm]
* **[C]** [AI tự gợi ý mẫu dựa trên sản phẩm]
* **[D]** [AI tự gợi ý mẫu dựa trên sản phẩm]
* **[E]** Nhập mô tả USP của riêng bạn (tự viết).
👉 *Nhập **A**, **B**, **C**, **D** để chọn nhanh, hoặc gõ trực tiếp câu trả lời của bạn vào ô chat nhé!*

(AI dừng lại chờ tôi trả lời câu hỏi này trước khi chuyển sang Bước 3).

---

${bul.main} BƯỚC 3: PHÂN TÍCH RÀO CẢN KHÁCH HÀNG (AI đặt Câu hỏi 5)
### 💡 BƯỚC 3: PHÂN TÍCH RÀO CẢN KHÁCH HÀNG (ICP PAIN POINT)

> 📌 **TƯ DUY THỰC CHIẾN: Tại sao cần giải quyết rào cản tâm lý của khách hàng?**
> Khách hàng luôn có những nỗi sợ ẩn giấu trước khi chi tiền (sợ đắt, sợ không giống quảng cáo, sợ khó dùng). Khi ta chủ động đập tan rào cản bằng USP đã chọn, kịch bản sẽ đạt sức thuyết phục tối đa.

---

#### ❓ CÂU HỎI 5:
* **Lợi thế đặc biệt đó của sản phẩm sẽ giải quyết rào cản tâm lý hoặc nỗi sợ lớn nhất của khách hàng khi tiếp cận "${userData.industry}" như thế nào?**

---

#### 💡 PHAO CỨU SINH (GỢI Ý TỪ TRỢ LÝ):
* **[A]** [AI tự gợi ý giải pháp dựa trên USP đã chọn ở Bước 2]
* **[B]** [AI tự gợi ý giải pháp dựa trên USP đã chọn ở Bước 2]
* **[C]** [AI tự gợi ý giải pháp dựa trên USP đã chọn ở Bước 2]
* **[D]** [AI tự gợi ý giải pháp dựa trên USP đã chọn ở Bước 2]
* **[E]** Nhập mô tả cách giải quyết rào cản của riêng bạn (tự viết).
👉 *Nhập **A**, **B**, **C**, **D** để chọn nhanh, hoặc gõ trực tiếp câu trả lời của bạn vào ô chat nhé!*

(AI dừng lại chờ tôi trả lời câu hỏi này trước khi chuyển sang Bước 4).

---

${bul.main} BƯỚC 4: TẠO BODY CỐ ĐỊNH & VÒNG LẶP MỞ (Phê duyệt Body)
### 📝 BƯỚC 4: TẠO THÂN BÀI CHIẾN LƯỢC (BODY)

> 📌 **TƯ DUY THỰC CHIẾN: Cách viết phần Body lõi giữ chân người xem?**
> Thân bài cần truyền đạt nhanh, gọn các luận điểm đắt giá theo đúng công thức marketing ${userData.fwCode} đã chọn. Việc chia nhỏ các câu thoại giúp nhịp điệu video lôi cuốn và dễ dựng B-roll hơn.

---

#### 🎬 BẢN DỰ THẢO THÂN BÀI:
\`\`\`text
[BODY - ${userData.fwCode}] (xx từ)
---
Ý 1... [//]
Ý 2... [//]
...
\`\`\`
*(Ký hiệu [//] dùng để đánh dấu nhịp cắt cảnh, không viết chữ [CẮT CẢNH])*

---

#### ❓ PHÊ DUYỆT THÂN BÀI:
* **Lựa chọn A:** Đồng ý và chuyển sang Bước 5 đề xuất Hook.
* **Lựa chọn B:** Thử viết lại Body này bằng một công thức khác (PAS / AIDA / HRR).
* **Lựa chọn C:** Nhập trực tiếp yêu cầu chỉnh sửa của riêng bạn tại đây.
👉 *Nhập **A** hoặc **B** để chọn nhanh, hoặc gõ yêu cầu điều chỉnh của bạn nhé!*

(AI dừng lại chờ tôi trả lời).

---

${bul.main} BƯỚC 5: ĐỀ XUẤT 5 HOOK CHẶN NGÓN TAY (Chọn Hook)
### 🎬 BƯỚC 5: ĐỀ XUẤT 5 HOOK CHẶN NGÓN TAY (Chọn Hook)

> 📌 **TƯ DUY THỰC CHIẾN: Tại sao cần 3 giây đầu tiên thật bùng nổ?**
> Hook là mồi nhử giữ chân người xem không lướt qua video. Chúng tôi đề xuất 5 hướng tiếp cận khác nhau giúp bạn lựa chọn đúng tâm lý khách hàng mục tiêu nhất.

---

#### 🎯 5 PHƯƠNG ÁN HOOK GỢI Ý:
1. **[Đâm thẳng nỗi đau]:** [Nội dung Hook 1]
2. **[Lật ngược định kiến]:** [Nội dung Hook 2]
3. **[Bằng chứng thực tế]:** [Nội dung Hook 3]
4. **[POV / Storytelling]:** [Nội dung Hook 4]
5. **[Câu hỏi gây tranh cãi]:** [Nội dung Hook 5]

---

#### ❓ LỰA CHỌN CỦA BẠN:
👉 *Vui lòng nhập số của Hook bạn chọn (từ 1 đến 5), hoặc gõ trực tiếp yêu cầu điều chỉnh Hook của bạn.*

(AI dừng lại chờ tôi trả lời).

---

${bul.main} BƯỚC 6: ĐỀ XUẤT 3 CTA CHỐT HẠ (Chọn CTA)
### 🎯 BƯỚC 6: ĐỀ XUẤT 3 CTA CHỐT HẠ (Chọn CTA)

> 📌 **TƯ DUY THỰC CHIẾN: Làm sao để kêu gọi hành động ra đơn hiệu quả?**
> Một CTA (Call to Action) tốt phải kích thích người dùng click/mua hàng ngay lập tức bằng lợi ích rõ ràng.

---

#### 🛒 3 PHƯƠNG ÁN CTA GỢI Ý:
* **Phương án 1:** [Nội dung CTA 1]
* **Phương án 2:** [Nội dung CTA 2]
* **Phương án 3:** [Nội dung CTA 3]

---

#### ❓ LỰA CHỌN CỦA BẠN:
👉 *Vui lòng nhập số của CTA bạn chọn (từ 1 đến 3), hoặc gõ trực tiếp yêu cầu điều chỉnh CTA của bạn.*

(AI dừng lại chờ tôi trả lời).

${bul.main} BƯỚC TRIỂN KHAI: LẮP RÁP KỊCH BẢN QUẢNG CÁO HOÀN CHỈNH
Lắp ráp Hook + Body + CTA thành một kịch bản hoàn chỉnh, đếm chính xác số từ (bắt buộc dưới 200 từ) và trình bày theo định dạng chuẩn:

=== KỊCH BẢN VIDEO QUẢNG CÁO ===
Tổng: XX từ | ~XX giây | Nhịp cắt: XX cảnh [//]

- HOOK (XX từ / ~Xs)
[Nội dung hook]
${bul.arrow} Hướng dẫn quay: [mô tả góc quay, biểu cảm]
${bul.arrow} Text overlay: [chữ hiện trên màn hình nếu có]

- BODY (XX từ / ~Xs) — ${userData.fwCode}
[Nội dung Body chia nhỏ từng câu ngắn kết thúc bằng ký hiệu [//]]
${bul.arrow} B-roll gợi ý: [các cảnh quay chèn phụ hoạ]

- CTA (XX từ / ~Xs)
[Nội dung CTA]
${bul.arrow} Hướng dẫn quay: [mô tả hành động của nhân vật]

BẮT BUỘC:
${bul.sub} Đếm chính xác tổng số từ. Vi phạm giới hạn 200 từ = THẤT BẠI.
${bul.sub} Giọng điệu của bạn: ${chosenTone.name} (${chosenTone.desc}).

${div}

${chosenOutro}`;
  }

  // 9. HELPERS
  function getNowTime() {
    const d = new Date();
    return d.getHours().toString().padStart(2, '0') + ':' + d.getMinutes().toString().padStart(2, '0');
  }

  function scrollB() {
    const chatDiv = document.getElementById('chat');
    chatDiv.scrollTop = chatDiv.scrollHeight;
  }

  function toggleInput(on) {
    uin.disabled = !on;
    sbtn.disabled = !on;
    uin.placeholder = on ? 'Nhập câu trả lời của bạn...' : 'Miss Video Ads đang phân tích...';
  }

  function setProgress(cur, tot) {
    prog.style.width = ((cur / tot) * 100) + '%';
  }

  function renderTags(tagsList) {
    qtags.innerHTML = '';
    tagsList.forEach((t) => {
      const b = document.createElement('button');
      b.className = 'qt';
      b.textContent = t;
      b.onclick = () => {
        uin.value = t;
        send();
      };
      qtags.appendChild(b);
    });
  }

  // Close Co-Pilot logic listeners
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "UPDATE_STATUS") {
      const statusBar = document.getElementById("status-bar");
      const statusText = document.getElementById("status-text");
      if (statusBar && statusText) {
        statusBar.style.display = "flex";
        statusText.innerHTML = `<strong>Theo dõi:</strong> ${message.statusText}`;
      }
    }
  });

  const statusBarCloseBtn = document.getElementById("close-panel-btn");
  if (statusBarCloseBtn) {
    statusBarCloseBtn.onclick = () => {
      window.close();
    };
  }

  function clearTags() {
    qtags.innerHTML = '';
  }

  // escape HTML helper
  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function showToast(msg) {
    const t = document.getElementById('toast');
    t.innerHTML = msg;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 2400);
  }

  function copyText(text) {
    (navigator.clipboard?.writeText(text) ?? Promise.reject()).catch(() => {
      const ta = Object.assign(document.createElement('textarea'), { value: text });
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();
    });
    showToast("✓ Đã sao chép prompt!");
  }

  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  // Input Listeners
  sbtn.addEventListener("click", send);
  uin.addEventListener("keydown", (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      send();
    }
  });

  // BOOT CONVERSATION
  await sleep(150);
  await askQ1();
});
