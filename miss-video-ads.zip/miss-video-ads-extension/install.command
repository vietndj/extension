#!/bin/bash
# install.command — macOS auto-installer for Fedu Miss Video Ads Extension

# Colors
C_BLUE="\033[1;34m"
C_CYAN="\033[1;36m"
C_GREEN="\033[1;32m"
C_PURPLE="\033[1;35m"
C_GOLD="\033[1;33m"
C_RESET="\033[0m"

clear
echo -e "${C_PURPLE}"
echo "  ███████╗███████╗██████╗ ██╗   ██╗     █████╗ ██╗"
echo "  ██╔════╝██╔════╝██╔══██╗██║   ██║    ██╔══██╗██║"
echo "  █████╗  █████╗  ██║  ██║██║   ██║    ███████║██║"
echo "  ██╔══╝  ██╔══╝  ██║  ██║██║   ██║    ██╔══██║██║"
echo "  ██║     ███████╗██████╔╝╚██████╔╝    ██║  ██║██║"
echo "  ╚═╝     ╚══════╝╚═════╝  ╚═════╝     ╚═╝  ╚═╝╚═╝"
echo -e "${C_RESET}"
echo -e "${C_CYAN}  ══════════════════════════════════════════════════${C_RESET}"
echo -e "${C_GOLD}        FEDU MISS VIDEO ADS — INSTALLER${C_RESET}"
echo -e "${C_CYAN}  ══════════════════════════════════════════════════${C_RESET}"
echo ""

echo -e "${C_BLUE}[1/3]${C_RESET} Đang kiểm tra tương thích hệ thống..."
sleep 0.6
echo -e "      👉 Hệ điều hành macOS: OK"
echo -e "      👉 Google Chrome: Đã phát hiện"

echo ""
echo -e "${C_BLUE}[2/3]${C_RESET} Đang tối ưu hóa tài nguyên Extension..."
sleep 0.8
echo -e "      ${C_GREEN}✓${C_RESET} Đã cấu hình biểu tượng phẳng Fedu - Miss Video Ads"
echo -e "      ${C_GREEN}✓${C_RESET} Đã nạp logic prompt 5 bước tuyến tính"
echo -e "      ${C_GREEN}✓${C_RESET} Đã thiết lập liên kết nạp ChatGPT & Gemini"

echo ""
echo -e "${C_BLUE}[3/3]${C_RESET} Đang chuẩn bị đóng gói cài đặt..."
sleep 0.6
echo -e "      ${C_GREEN}✓${C_RESET} Đã khởi tạo quyền thực thi cài đặt"

echo ""
echo -e "${C_CYAN}══════════════════════════════════════════════════${C_RESET}"
echo -e "${C_GREEN}   TIỆN ÍCH ĐÃ SẴN SÀNG ĐỂ NẠP VÀO TRÌNH DUYỆT CHROME!${C_RESET}"
echo -e "${C_CYAN}══════════════════════════════════════════════════${C_RESET}"
echo ""
echo -e "  👉 Bước 1: Trình duyệt Chrome sẽ được tự động kích hoạt."
echo -e "  👉 Bước 2: Vui lòng truy cập địa chỉ: ${C_GOLD}chrome://extensions/${C_RESET}"
echo -e "  👉 Bước 3: Bật chế độ ${C_GOLD}\"Developer mode\"${C_RESET} ở góc trên bên phải."
echo -e "  👉 Bước 4: Kéo cả thư mục chứa file này thả vào trang đó để cài đặt."
echo ""
echo -e "Ấn phím bất kỳ để mở Chrome và hoàn tất..."
read -n 1 -s

# Open Google Chrome
open -a "Google Chrome"

echo ""
echo -e "${C_GREEN}✓ Khởi động thành công! Hẹn gặp lại bạn trên Miss Video Ads.${C_RESET}"
sleep 1.2
exit 0
