// content.js — Content Script programmatically injected into https://gemini.google.com/* and https://chatgpt.com/*

if (!window.novaListenerRegistered) {
  window.novaListenerRegistered = true;

  try {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === "INJECT_PROMPT") {
        injectPrompt(message.prompt)
          .then((detail) => {
            sendResponse({ success: true, detail });
          })
          .catch((err) => {
            console.error("[Nova Co-Pilot] Injection failed:", err);
            sendResponse({ success: false, error: err.message });
          });
        return true; // Keep message channel open for async response
      }
    });

    // Start observing the page immediately to report status back to side panel
    startPageObserver();
  } catch (e) {
    console.warn("[Nova Co-Pilot] Extension context invalidated during setup:", e);
  }

  console.log("[Nova Co-Pilot] Content script successfully loaded & registered.");
}

// ── STATUS MONITORING ──
function startPageObserver() {
  const detectAndReport = () => {
    const text = document.body.innerText || "";
    let step = null;
    
    if (text.includes("KỊCH BẢN VIDEO QUẢNG CÁO") || text.includes("KỊCH BẢN VIDEO —") || text.includes("KỊCH BẢN VIDEO QUẢNG CÁO ===")) {
      step = "Đã hoàn thiện kịch bản! 🎉";
    } else if (text.includes("BƯỚC 6:") || text.includes("CTA CHỐT HẠ") || text.includes("CTA (từ 1 đến 3)")) {
      step = "Đang chọn CTA (Bước 6/6) 🎯";
    } else if (text.includes("BƯỚC 5:") || text.includes("HOOK CHẶN NGÓN TAY") || text.includes("Hook (từ 1 đến 5)")) {
      step = "Đang chọn Hook (Bước 5/6) 🎬";
    } else if (text.includes("BƯỚC 4:") || text.includes("TẠO BODY CỐ ĐỊNH") || text.includes("xử lý phần Body:")) {
      step = "Đang duyệt Body (Bước 4/6) 📝";
    } else if (text.includes("BƯỚC 3:") || text.includes("Câu hỏi 5:") || text.includes("rào cản tâm lý")) {
      step = "Đang phỏng vấn rào cản (Bước 3/6) 🛡️";
    } else if (text.includes("BƯỚC 2:") || text.includes("Câu hỏi 4:") || text.includes("USP của sản phẩm")) {
      step = "Đang phỏng vấn USP (Bước 2/6) 💬";
    }
    
    if (step) {
      try {
        chrome.runtime.sendMessage({ action: "UPDATE_STATUS", statusText: step }, () => {
          // Suppress unchecked runtime.lastError warning by reading it
          const err = chrome.runtime.lastError;
        });
      } catch (e) {
        // Silent catch: extension context invalidated (normal during reload)
      }
    }
  };

  // Run immediately
  setTimeout(detectAndReport, 1000);

  // Monitor DOM changes to catch updates as the chat progresses
  const observer = new MutationObserver(() => {
    detectAndReport();
  });
  observer.observe(document.body, { childList: true, subtree: true });
}

// ── PROMPT INJECTION LOGIC ──
async function injectPrompt(promptText) {
  const isChatGPT = window.location.hostname.includes("chatgpt.com");

  if (isChatGPT) {
    return await injectChatGPT(promptText);
  } else {
    return await injectGemini(promptText);
  }
}

// ── GEMINI INJECTION ──
async function injectGemini(promptText) {
  const inputEl = document.querySelector('div[contenteditable="true"]');
  if (!inputEl) {
    throw new Error("Không tìm thấy ô nhập liệu Gemini. Đảm bảo bạn đang ở trang chat của Gemini và trang đã tải xong.");
  }

  inputEl.focus();
  inputEl.innerText = promptText;

  inputEl.dispatchEvent(new Event('input', { bubbles: true }));
  inputEl.dispatchEvent(new Event('change', { bubbles: true }));

  await new Promise((resolve) => setTimeout(resolve, 150));

  const sendSelectors = [
    'button[aria-label*="Send"]',
    'button[aria-label*="Gửi"]',
    'button[aria-label*="message"]',
    'button[aria-label*="tin nhắn"]',
    'button.send-button'
  ];

  let sendBtn = null;
  for (const selector of sendSelectors) {
    sendBtn = document.querySelector(selector);
    if (sendBtn) break;
  }

  if (!sendBtn) {
    const buttons = Array.from(document.querySelectorAll('button'));
    sendBtn = buttons.find((btn) => {
      const label = (btn.getAttribute('aria-label') || '').toLowerCase();
      const title = (btn.getAttribute('title') || '').toLowerCase();
      return (
        label.includes('send') ||
        label.includes('gửi') ||
        title.includes('send') ||
        title.includes('gửi')
      );
    });
  }

  if (!sendBtn) {
    const wrapper = inputEl.closest('rich-textarea') || inputEl.parentElement;
    if (wrapper) {
      sendBtn = wrapper.querySelector('button');
    }
  }

  if (!sendBtn) {
    return "Đã điền prompt vào ô nhập liệu thành công! Vui lòng bấm nút Gửi trên giao diện Gemini để bắt đầu.";
  }

  sendBtn.click();
  return "Đã điền và gửi prompt thành công!";
}

// ── CHATGPT INJECTION ──
async function injectChatGPT(promptText) {
  const inputEl = document.querySelector('#prompt-textarea') || 
                  document.querySelector('div[contenteditable="true"]') ||
                  document.querySelector('div[role="textbox"]');

  if (!inputEl) {
    throw new Error("Không tìm thấy ô nhập liệu ChatGPT. Đảm bảo bạn đang ở trang chat và trang đã tải xong.");
  }

  inputEl.focus();
  
  try {
    document.execCommand('selectAll', false, null);
    document.execCommand('insertText', false, promptText);
  } catch (e) {
    inputEl.innerText = promptText;
  }

  inputEl.dispatchEvent(new Event('input', { bubbles: true }));
  inputEl.dispatchEvent(new Event('change', { bubbles: true }));

  await new Promise((resolve) => setTimeout(resolve, 200));

  const sendSelectors = [
    'button[data-testid="send-button"]',
    'button[aria-label*="Send"]',
    'button[aria-label*="Gửi"]',
    'button[class*="send"]',
    'button.mb-1.5'
  ];

  let sendBtn = null;
  for (const selector of sendSelectors) {
    sendBtn = document.querySelector(selector);
    if (sendBtn) break;
  }

  if (!sendBtn) {
    const buttons = Array.from(document.querySelectorAll('button'));
    sendBtn = buttons.find((btn) => {
      const aria = (btn.getAttribute('aria-label') || '').toLowerCase();
      const testid = (btn.getAttribute('data-testid') || '').toLowerCase();
      return aria.includes('send') || aria.includes('gửi') || testid.includes('send');
    });
  }

  if (!sendBtn) {
    return "Đã điền prompt vào ô nhập liệu ChatGPT! Vui lòng bấm nút gửi thủ công.";
  }

  sendBtn.click();
  return "Đã điền và gửi prompt sang ChatGPT thành công!";
}
