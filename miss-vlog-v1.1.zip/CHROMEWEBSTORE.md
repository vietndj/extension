# Chrome Web Store Listing — Miss Vlog

This document contains the metadata, description, permissions justification, and version history for the **Miss Vlog** Chrome Extension. Use this information to publish or update the extension in the Chrome Developer Dashboard.

---

## 1. Store Metadata

- **Title (Max 45 chars):** Miss Vlog — Trợ Lý Kịch Bản Xây Kênh
- **Summary (Max 132 chars):** Chuyên gia AI đồng hành sáng tạo kịch bản video ngắn xây dựng thương hiệu cá nhân cuốn hút chỉ với vài bước đơn giản.
- **Category:** Productivity / Developer Tools
- **Default Language:** Vietnamese (vi)

---

## 2. Detailed Description (CWS Listing Description)

**Miss Vlog** là "Trợ Lý Kịch Bản Xây Kênh" — nữ chuyên gia AI trẻ trung, năng động và am hiểu sâu sắc về xu hướng sáng tạo nội dung video ngắn (TikTok, Reels, Shorts) giúp các nhà sáng tạo và cá nhân tự tin xây dựng thương hiệu cá nhân cuốn hút.

Extension hoạt động trực tiếp trên Side Panel của trình duyệt Chrome và đồng bộ tự động với ChatGPT hoặc Gemini để cùng bạn đi qua các bước biên tập kịch bản chuyên nghiệp:

* **Bước 1 — Định vị chủ đề & Góc nhìn độc đáo:** Giúp bạn khai thác ngách nội dung từ trải nghiệm thực tế và chọn tông giọng phù hợp.
* **Bước 2 — Cấu trúc Hook 3 giây vàng:** Tự động đề xuất các mẫu câu mở đầu gây chú ý, giữ chân người xem ngay từ những giây đầu tiên.
* **Bước 3 — Phát triển nội dung giá trị:** Chuyển thể ý tưởng thành kịch bản phân cảnh chi tiết (Lời thoại, Hành động camera, Ghi chú biểu cảm).
* **Bước 4 — Kêu gọi hành động (CTA) chuyển đổi:** Tối ưu hóa câu kết thúc để tăng lượt theo dõi, bình luận và chia sẻ tự nhiên.

**Tính năng chính:**
1. Giao diện Side Panel hiện đại, tông màu cam năng động, dễ sử dụng.
2. Tự động nạp Mega Prompt tối ưu hóa trực tiếp vào ChatGPT hoặc Gemini.
3. Thanh trạng thái đồng bộ thời gian thực hiển thị tiến trình kịch bản.
4. Lưu giữ tên và cấu hình cá nhân hóa trên thiết bị của bạn.

---

## 3. Permissions Justification

| Permission / Host | Type | Plain-English Justification |
| :--- | :--- | :--- |
| `sidePanel` | Permission | Required to host the Miss Vlog companion chat interface directly inside the browser's side panel. |
| `tabs` | Permission | Required to inspect active tab URLs to detect if the user is on a supported AI platform (ChatGPT or Gemini). |
| `scripting` | Permission | Required to inject script content into active ChatGPT or Gemini tabs to programmatically populate the prompt input. |
| `storage` | Permission | Required to save user preferences and project state locally on the device (`chrome.storage.local`). |
| `https://gemini.google.com/*` | Host Permission | Required to interact with Google Gemini page input fields to send prepared prompts automatically. |
| `https://chatgpt.com/*` | Host Permission | Required to interact with ChatGPT page input fields to send prepared prompts automatically. |

---

## 4. Privacy & Data Use

- **Data Collection:** Miss Vlog does **NOT** collect, store, or transmit any user data, emails, or browsing history to external servers.
- **Local Processing:** All inputs (topic, target audience, format) are processed locally on your device via `chrome.storage.local`.
- **Third-Party Sharing:** Data is only sent to ChatGPT or Gemini tabs upon direct user interaction.

---

## 5. Version History

### Version 1.1 (2026-07-24)
- Performance and stability enhancements for ChatGPT and Gemini DOM injection.
- Updated Chrome Web Store listing metadata and privacy policy documentation.

### Version 1.0 (2026-07-15)
- Initial release.
- Fully automated Vlog script creation wizard on Side Panel.
- One-click prompt injection for ChatGPT and Gemini.
