# Chrome Web Store Listing — Miss Video Ads

This document contains the metadata, description, permissions justification, and version history for the **Miss Video Ads** Chrome Extension. Use this information to publish or update the extension in the Chrome Developer Dashboard.

---

## 1. Store Metadata

- **Title (Max 45 chars):** Miss Video Ads — Trợ Lý Kịch Bản
- **Summary (Max 132 chars):** Nữ biên kịch AI đồng hành sáng tạo kịch bản video ads siêu tốc, chuẩn công thức marketing chỉ với vài bước đơn giản.
- **Category:** Productivity / Developer Tools
- **Default Language:** Vietnamese (vi)

---

## 2. Detailed Description (CWS Listing Description)

**Miss Video Ads** là "Nữ Biên Kịch AI" chuyên nghiệp đồng hành cùng doanh nghiệp, cửa hàng và marketer tạo ra những kịch bản video quảng cáo sản phẩm/dịch vụ bán hàng siêu tốc và gia tăng tỷ lệ chuyển đổi.

Extension chạy trực tiếp trên Side Panel trình duyệt Chrome và đồng bộ tự động với ChatGPT hoặc Gemini theo các công thức marketing đỉnh cao (AIDA, PAS, FAB, SSS):

* **Bước 1 — Phân tích sản phẩm & Khách hàng mục tiêu:** Khai thác nỗi đau khách hàng và điểm bán hàng độc nhất (USP) của sản phẩm.
* **Bước 2 — Mở đầu giật gân (Hook):** Tạo 3 phương án mở đầu đánh trúng tâm lý, giữ chân người xem ngay trong 3 giây đầu.
* **Bước 3 — Dẫn dắt giải pháp & Bằng chứng:** Trình bày tính năng, lợi ích sản phẩm kèm các gợi ý phân cảnh B-roll minh họa thực tế.
* **Bước 4 — Chốt sale & Ưu đãi (Call to Action):** Tạo lời kêu gọi mua hàng quyết liệt kèm thông điệp khẩn cấp (Urgency/Scarcity).

**Tính năng chính:**
1. Giao diện Side Panel sang trọng với tông màu tím quyến rũ.
2. Tự động nạp Mega Prompt quảng cáo tối ưu hóa trực tiếp vào ChatGPT hoặc Gemini.
3. Live Status Monitor hiển thị bước kịch bản hiện tại.
4. Tùy chọn sao chép prompt linh hoạt.

---

## 3. Permissions Justification

| Permission / Host | Type | Plain-English Justification |
| :--- | :--- | :--- |
| `sidePanel` | Permission | Required to host the Miss Video Ads companion chat interface directly inside the browser's side panel. |
| `tabs` | Permission | Required to inspect active tab URLs to detect if the user is on a supported AI platform (ChatGPT or Gemini). |
| `scripting` | Permission | Required to inject script content into active ChatGPT or Gemini tabs to programmatically populate the prompt input. |
| `storage` | Permission | Required to save user preferences and project state locally on the device (`chrome.storage.local`). |
| `https://gemini.google.com/*` | Host Permission | Required to interact with Google Gemini page input fields to send prepared prompts automatically. |
| `https://chatgpt.com/*` | Host Permission | Required to interact with ChatGPT page input fields to send prepared prompts automatically. |

---

## 4. Privacy & Data Use

- **Data Collection:** Miss Video Ads does **NOT** collect, store, or transmit any user data, emails, or browsing history to external servers.
- **Local Processing:** All inputs (product name, target audience, angle) are processed locally on your device via `chrome.storage.local`.
- **Third-Party Sharing:** Data is only sent to ChatGPT or Gemini tabs upon direct user interaction.

---

## 5. Version History

### Version 1.1 (2026-07-24)
- Optimized DOM automation for ChatGPT and Gemini interfaces.
- Updated Chrome Web Store listing documentation and privacy guidelines.

### Version 1.0 (2026-07-15)
- Initial release.
- Fully automated Video Ads script creation wizard on Side Panel.
- One-click prompt injection for ChatGPT and Gemini.
