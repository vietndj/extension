// sidepanel.js — Chat logic controller for Miss Vlog Script Coach Panel (Gemini & ChatGPT support)

document.addEventListener("DOMContentLoaded", async () => {
  // DOM Elements
  const cw = document.getElementById("cw");
  const uin = document.getElementById("uin");
  const sbtn = document.getElementById("sbtn");
  const qtags = document.getElementById("qtags");
  const prog = document.getElementById("prog");

  // State Management
  let step = 0;
  let busy = false;
  let waitingToOpen = false;

  let userData = {
    topic: "",
    format: "",       // [1], [2] or [3]
    formatLabel: "",  // Descriptive name
    duration: ""      // 15, 30, 60, 75, >75
  };

  // 1. CHUNK TYPEWRITER ANIMATION
  function chunk(el, html, n = 3, ms = 12) {
    return new Promise((resolve) => {
      el.innerHTML = '';
      const tokens = [];
      const re = /(<[^>]+>|&[^;]+;|[\s\S])/g;
      let m;
      while ((m = re.exec(html)) !== null) tokens.push(m[0]);
      
      let i = 0;
      const CUR = '<span class="cur"></span>';
      
      function tick() {
        if (i >= tokens.length) {
          el.innerHTML = html;
          resolve();
          return;
        }
        let added = 0;
        while (i < tokens.length && added < n) {
          i++;
          if (!tokens[i - 1].startsWith('<')) added++;
        }
        el.innerHTML = tokens.slice(0, i).join('') + CUR;
        scrollB();
        const last = tokens[i - 1] || '';
        const delay = last === '.' || last === '!' || last === '?' ? 120 : last === ',' ? 60 : ms;
        setTimeout(tick, delay);
      }
      tick();
    });
  }

  // 2. CHAT BUILDERS
  async function vlogSay(html) {
    busy = true;
    toggleInput(false);
    
    const row = document.createElement('div');
    row.className = 'msg';
    const vlogGradId = 'vlog-g-' + Math.random().toString(36).substr(2, 9);
    row.innerHTML = `
      <div class="mav nova">
        <svg viewBox="0 0 24 24" width="20" height="20" style="display: block;">
          <defs>
            <linearGradient id="${vlogGradId}" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#ff7e5f" />
              <stop offset="50%" stop-color="#feb47b" />
              <stop offset="100%" stop-color="#ff6b6b" />
            </linearGradient>
          </defs>
          <path d="M8 5v14l11-7z" fill="url(#${vlogGradId})" />
          <path d="M17 3a1 1 0 0 1 1 1v2a1 1 0 0 0 1 1h2a1 1 0 0 1 0 2h-2a1 1 0 0 0-1 1v2a1 1 0 0 1-2 0V10a1 1 0 0 0-1-1h-2a1 1 0 0 1 0-2h2a1 1 0 0 0 1-1V4a1 1 0 0 1 1-1z" fill="#feb47b" opacity="0.9" />
        </svg>
      </div>
      <div class="bubble"><div class="txt"></div>
      <div class="bm"><svg viewBox="0 0 24 24" width="10" height="10" fill="var(--primary-color)" style="margin-right:2px"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg> ${getNowTime()}</div></div>`;
    
    const txt = row.querySelector('.txt');
    cw.appendChild(row);
    scrollB();
    
    await chunk(txt, html, 3, 10);
    busy = false;
    toggleInput(true);
  }

  function userSay(text) {
    const row = document.createElement('div');
    row.className = 'msg user';
    row.innerHTML = `
      <div class="mav human"><svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor" style="display: block;"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg></div>
      <div class="bubble"><div class="txt"></div>
      <div class="bm"><svg viewBox="0 0 24 24" width="10" height="10" fill="#555" style="margin-right:2px"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg> ${getNowTime()}</div></div>`;
    
    row.querySelector('.txt').textContent = text;
    cw.appendChild(row);
    scrollB();
  }

  // 3. BOOTSTRAP INITIAL QUESTION
  async function askQ1() {
    await vlogSay(
      '👋 Chào bạn! Mình là <span class="h">Miss Vlog 🎬</span> — chuyên gia đồng hành thiết kế kịch bản video xây kênh thương hiệu cá nhân của riêng bạn.<br><br>' +
      '✍️ Đầu tiên, **chủ đề hoặc câu chuyện** bạn muốn chia sẻ trong video này là gì? (Ví dụ: dịch vụ spa, bán quần áo, hay đơn giản là vlog hành trình làm mẹ, kể chuyện cuộc sống hàng ngày...)<br><br>' +
      '💡 <em>Mẹo: Hãy viết mô tả càng chi tiết càng tốt. Nếu có sản phẩm bán, hãy nêu rõ. Nếu làm vlog đời sống, hãy mô tả về câu chuyện bạn muốn kể!</em>'
    );
    renderTags([
      'Hành trình chăm con mọn, chia sẻ với các mẹ bỉm',
      'Vlog một ngày làm việc của dân văn phòng',
      'Kinh doanh thời trang nữ, hướng tới Gen Z'
    ]);
    uin.focus();
  }

  // 4. ACTION PROCESSOR
  async function send() {
    const val = uin.value.trim();
    if (!val || busy) return;

    userSay(val);
    uin.value = '';
    clearTags();
    toggleInput(false);

    await sleep(400);

    // SUB-STATE: WAITING FOR TAB TO BE OPENED
    if (waitingToOpen) {
      if (val.includes("Gửi kịch bản ngay")) {
        await executePromptLaunch();
      } else if (val.includes("ChatGPT")) {
        await chrome.tabs.create({ url: 'https://chatgpt.com' });
        await vlogSay("🚀 Mình đã mở tab ChatGPT mới rồi nè! Đợi trang tải xong, bạn hãy bấm nút <strong>'Gửi kịch bản ngay ⚡'</strong> ở dưới để chạy nhé.");
        renderTags(["⚡ Gửi kịch bản ngay"]);
      } else if (val.includes("Gemini")) {
        await chrome.tabs.create({ url: 'https://gemini.google.com' });
        await vlogSay("🚀 Mình đã mở tab Gemini mới rồi nè! Đợi trang tải xong, bạn hãy bấm nút <strong>'Gửi kịch bản ngay ⚡'</strong> ở dưới để chạy nhé.");
        renderTags(["⚡ Gửi kịch bản ngay"]);
      }
      return;
    }

    // STATE 0: INDUSTRY SUBMITTED -> ASK FOR FORMAT
    if (step === 0) {
      userData.topic = val;
      setProgress(1, 3);

      await vlogSay(`📥 Chủ đề/Câu chuyện: <strong>"${val}"</strong> đã được ghi nhận thành công!`);
      await sleep(300);

      await vlogSay(
        `✨ Tiếp theo, bạn muốn chọn <strong>định dạng kể chuyện</strong> nào dưới đây để bắt đầu xây dựng nội dung? (Vui lòng chọn bên dưới):`
      );
      
      step = 1;
      renderTags([
        '💥 [1] Đập tan lầm tưởng (Góc nhìn mới)',
        '💡 [2] Chia sẻ mẹo vặt (Cầm tay chỉ việc)',
        '☕ [3] Chuyện thường ngày (Tâm sự)'
      ]);
      uin.placeholder = "Chọn định dạng kể chuyện...";
      toggleInput(false); // Force selecting tag button

    } else if (step === 1) {
      // STATE 1: FORMAT CHOSEN -> ASK FOR DURATION
      let formatVal = val;
      let formatCode = "1";
      if (formatVal.includes("[2]")) formatCode = "2";
      else if (formatVal.includes("[3]")) formatCode = "3";

      userData.format = formatCode;
      userData.formatLabel = formatVal;
      setProgress(2, 3);

      await vlogSay(`🎯 Định dạng kể chuyện đã chọn: <strong>"${formatVal}"</strong>.`);
      await sleep(300);

      await vlogSay(
        `⏱️ Cuối cùng, bạn muốn thiết lập **thời lượng video** mong muốn là bao nhiêu giây? <small><i>(Thời lượng sẽ quyết định cấu trúc mật độ từ vựng khoa học được nạp tự động sang AI)</i></small>:`
      );

      step = 2;
      renderTags([
        '⚡ 15 giây (Ngắn gọn)',
        '⏱️ 30 giây (Tiêu chuẩn)',
        '🎥 60 giây (Chia sẻ sâu)',
        '🎬 75 giây (Trải nghiệm thực tế)',
        '📊 Trên 75 giây (Chuyên sâu)'
      ]);
      uin.placeholder = "Chọn thời lượng video...";
      toggleInput(false);

    } else if (step === 2) {
      // STATE 2: DURATION CHOSEN -> LAUNCH
      let durVal = val;
      let durSec = "30";
      if (durVal.includes("15")) durSec = "15";
      else if (durVal.includes("60")) durSec = "60";
      else if (durVal.includes("75")) durSec = "75";
      else if (durVal.includes("Trên 75")) durSec = ">75";

      userData.duration = durSec;
      
      await executePromptLaunch();
    }
  }

  // 5. AUTO-INJECTION AND IMMEDIATE LAUNCH
  async function executePromptLaunch() {
    setProgress(3, 3);
    toggleInput(false);
    
    await vlogSay(`⚡ Đang đồng bộ hóa dữ liệu và chuyển cấu trúc kịch bản xây kênh sang trang chat AI...`);
    await sleep(350);

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    // Check if user is currently on a supported tab
    const isSupported = tab && tab.url && (tab.url.includes("gemini.google.com") || tab.url.includes("chatgpt.com"));
    
    if (!isSupported) {
      await vlogSay(
        `⚠️ Không tìm thấy tab ChatGPT hoặc Gemini đang mở ở cửa sổ hiện tại.<br><br>` +
        `Bạn hãy chọn nền tảng muốn chạy kịch bản bên dưới, mình sẽ mở tự động giúp bạn nhé:`
      );
      waitingToOpen = true;
      renderTags([
        "💬 Mở và gửi sang ChatGPT",
        "✨ Mở và gửi sang Gemini"
      ]);
      return;
    }

    waitingToOpen = false;
    const isChatGPT = tab.url.includes("chatgpt.com");
    const aiName = isChatGPT ? "ChatGPT" : "Gemini";

    // Auto-inject and auto-send
    try {
      // Inject content.js on-demand
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["content.js"]
      });

      const promptText = buildPrompt();

      // Send instruction safely
      const response = await new Promise((resolve) => {
        chrome.tabs.sendMessage(tab.id, {
          action: "INJECT_PROMPT",
          prompt: promptText
        }, (res) => {
          const err = chrome.runtime.lastError;
          if (err) {
            resolve({ success: false, error: err.message });
          } else {
            resolve(res);
          }
        });
      });

      if (response && response.success) {
        showToast("🎉 Khởi chạy kịch bản thành công!");
        await sleep(350);
        window.close();   // Automatically close the Side Panel
      } else {
        throw new Error(response ? response.error : "Không kết nối được với trang AI.");
      }
    } catch (err) {
      console.error(err);
      await renderFallbackPromptBox(err.message);
    }
  }

  // 6. RENDER FALLBACK PROMPT BOX (Manual Copy Fallback)
  async function renderFallbackPromptBox(errorMsg) {
    await vlogSay(
      `<span style="color:#ff6b6b;"><svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor" style="display:inline-block; vertical-align:middle; margin-right:4px;"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg> ⚠️ Lỗi kết nối tự động:</span> ${errorMsg}.<br><br>` +
      `Đã chuyển sang chế độ nạp thủ công 🛠️. Bạn có thể nhấn nút gửi lại bên dưới hoặc sao chép kịch bản để dán trực tiếp vào AI:`
    );

    const promptText = buildPrompt();
    const pid = 'pr_' + Date.now();

    const row = document.createElement('div');
    row.className = 'msg';
    const vlogGradPromptId = 'vlog-g-p-' + Math.random().toString(36).substr(2, 9);
    row.innerHTML = `
      <div class="mav nova">
        <svg viewBox="0 0 24 24" width="20" height="20" style="display: block;">
          <defs>
            <linearGradient id="${vlogGradPromptId}" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#ff7e5f" />
              <stop offset="50%" stop-color="#feb47b" />
              <stop offset="100%" stop-color="#ff6b6b" />
            </linearGradient>
          </defs>
          <path d="M8 5v14l11-7z" fill="url(#${vlogGradPromptId})" />
          <path d="M17 3a1 1 0 0 1 1 1v2a1 1 0 0 0 1 1h2a1 1 0 0 1 0 2h-2a1 1 0 0 0-1 1v2a1 1 0 0 1-2 0V10a1 1 0 0 0-1-1h-2a1 1 0 0 1 0-2h2a1 1 0 0 0 1-1V4a1 1 0 0 1 1-1z" fill="#feb47b" opacity="0.9" />
        </svg>
      </div>
      <div class="bubble" style="max-width:100%; border-color: rgba(255, 126, 95, 0.3)">
        <div style="font-size:11px;color:var(--text-dim);margin-bottom:6px">📝 Kịch bản chiến lược của bạn:</div>
        <div class="pbox" id="${pid}"><button class="cpbtn">📋 Sao chép</button>${escapeHtml(promptText)}</div>
        <div class="btn-row" style="flex-direction: column; gap: 8px;">
          <button class="open-ai-btn" id="btn-send-chatgpt" style="background: linear-gradient(135deg, #ff7e5f, #ff6b6b); box-shadow: 0 4px 10px rgba(255, 126, 95, 0.2);">
            💬 Gửi sang ChatGPT ⚡
          </button>
          <button class="open-ai-btn gemini" id="btn-send-gemini" style="background: linear-gradient(135deg, #feb47b, #ff7e5f); box-shadow: 0 4px 10px rgba(254, 180, 123, 0.2);">
            ✨ Gửi sang Gemini ⚡
          </button>
        </div>
      </div>`;

    const cpBtn = row.querySelector('.cpbtn');
    cpBtn.onclick = () => copyText(promptText);

    const btnChatGPT = row.querySelector('#btn-send-chatgpt');
    const btnGemini = row.querySelector('#btn-send-gemini');

    btnChatGPT.onclick = async () => {
      await handleSendAction("chatgpt.com", btnChatGPT, promptText);
    };

    btnGemini.onclick = async () => {
      await handleSendAction("gemini.google.com", btnGemini, promptText);
    };

    cw.appendChild(row);
    scrollB();

    clearTags();
    const rb = document.createElement('button');
    rb.className = 'qt';
    rb.innerHTML = '🔄 Làm lại kịch bản mới';
    rb.onclick = () => {
      window.location.reload();
    };
    qtags.appendChild(rb);
  }

  // 7. ACTION SEND HANDLER
  async function handleSendAction(domain, button, promptText) {
    const originalContent = button.innerHTML;
    button.disabled = true;
    button.textContent = "🔄 Đang kết nối...";

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const matchesDomain = tab && tab.url && tab.url.includes(domain);

    if (!matchesDomain) {
      const platformName = domain.includes("chatgpt") ? "ChatGPT" : "Gemini";
      const targetUrl = domain.includes("chatgpt") ? "https://chatgpt.com" : "https://gemini.google.com";
      
      await vlogSay(
        `⚠️ Bạn cần mở tab <strong class="h">${platformName}</strong> để gửi kịch bản nhé.<br><br>` +
        `🚀 Mình đang tự động mở tab mới giúp bạn. Sau khi trang tải xong, hãy nhấn lại nút <strong>"Gửi sang ${platformName} ⚡"</strong> ở bảng điều khiển để chạy.`
      );
      
      await chrome.tabs.create({ url: targetUrl });
      
      button.disabled = false;
      button.innerHTML = originalContent;
      return;
    }

    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["content.js"]
      });

      const response = await new Promise((resolve) => {
        chrome.tabs.sendMessage(tab.id, {
          action: "INJECT_PROMPT",
          prompt: promptText
        }, (res) => {
          const err = chrome.runtime.lastError;
          if (err) {
            resolve({ success: false, error: err.message });
          } else {
            resolve(res);
          }
        });
      });

      if (response && response.success) {
        const statusBar = document.getElementById("status-bar");
        const statusText = document.getElementById("status-text");
        if (statusBar && statusText) {
          statusBar.style.display = "flex";
          statusText.innerHTML = "🔄 Đang đồng bộ cuộc trò chuyện...";
        }

        showToast("🎉 Đã nạp và gửi prompt tự động!");
        button.disabled = false;
        button.innerHTML = `🎉 Đã nạp thành công`;
        button.style.background = "linear-gradient(135deg, #10b981, #059669)";
        
        await vlogSay(`🎉 Đã gửi kịch bản thành công sang <strong>${domain.includes("chatgpt") ? "ChatGPT" : "Gemini"}</strong> bên trái rồi nè! Bạn có thể bắt đầu tương tác nhé. 💬`);
      } else {
        throw new Error(response ? response.error : "Không nhận được phản hồi nạp dữ liệu.");
      }
    } catch (e) {
      console.error(e);
      await vlogSay(`⚠️ Lỗi gửi tự động: ${e.message}. Bạn hãy copy kịch bản thủ công bằng nút bên trên nhé. 🛠️`);
      button.disabled = false;
      button.innerHTML = originalContent;
    }
  }

  // 8. BUILD PROMPT TEMPLATE (Synchronized 100% with the tested Miss Vlog Mega Prompt)
  function buildPrompt() {
    return `# VAI TRÒ
Bạn là Miss Vlog - Chuyên gia đồng hành xây kênh thương hiệu (Organic Growth Coach) thực chiến. Khách hàng của bạn là những người kinh doanh, chuyên gia MỚI BẮT ĐẦU xây dựng thương hiệu cá nhân - họ chưa biết cách lập bố cục nội dung, lúng túng trước ống kính và dễ bị quá tải.
Nhiệm vụ của bạn là hướng dẫn họ từng bước để tạo ra kịch bản video ngắn chân thực, tự nhiên, làm nổi bật giá trị chuyên môn và tối ưu thời lượng giữ chân người xem.

# RÀNG BUỘC PHÂN DÒNG & SỐ TỪ THỰC TẾ (BẮT BUỘC TUÂN THỦ)
Để tránh tình trạng viết thiếu từ cho các video dài, bạn phải tăng số lượng dòng (Row) ở phần Thân bài và kéo dài câu thoại của mỗi dòng để đảm bảo mật độ từ vựng chính xác:

* **Video 15s (35 - 40 từ thoại):** Bắt buộc gồm 1 dòng Mở bài (10 từ) + 1 dòng Thân bài (20 từ) + 1 dòng Kết luận (10 từ).
* **Video 30s (75 - 85 từ thoại):** Bắt buộc gồm 1 dòng Mở bài (15 từ) + 2 dòng Thân bài (mỗi dòng ~25 từ) + 1 dòng Kết luận (15 từ).
* **Video 60s (140 - 150 từ thoại):** Bắt buộc gồm 1 dòng Mở bài (20 từ) + 3 đến 4 dòng Thân bài (mỗi dòng ~30 từ) + 1 dòng Kết luận (20 từ).
* **Video 75s (175 - 190 từ thoại):** Bắt buộc gồm 1 dòng Mở bài (25 từ) + 4 đến 5 dòng Thân bài (mỗi dòng ~30 từ) + 1 dòng Kết luận (25 từ).
* **Video >75s (200 - 220 từ thoại):** Bắt buộc gồm 1 dòng Mở bài (25 từ) + 5 đến 6 dòng Thân bài (mỗi dòng ~30 từ) + 1 dòng Kết luận (25 từ).

> ⚠️ **Cảnh báo lỗi đếm từ (Cấm tuyệt đối):** Không được sinh ra kịch bản ngắn (dưới 100 từ) cho video 60s/75s rồi điền bừa số từ giả ở tiêu đề. Bạn phải viết các câu thoại trong cột thoại dài ra, đầy đủ phân tích chuyên môn. Sau khi viết xong, hãy đếm chính xác số từ thực tế của lời thoại (chỉ tính phần nằm trong dấu ngoặc kép "") rồi mới ghi vào mô tả (VD: "Số từ thực tế: 145 từ").

# NGUYÊN TẮC LÀM VIỆC TỐI QUAN TRỌNG (UX & TÔNG GIỌNG)
1. TÔNG GIỌNG CHUYÊN NGHIỆP & GẦN GŨI: Xưng hô "mình - bạn" tự nhiên. Nói năng thẳng thắn, thực tế, không dùng từ ngữ sáo rỗng hay tâng bốc. Tập trung vào giải pháp cụ thể.
2. TƯƠNG TÁC TUYẾN TÍNH (STEP-BY-STEP): Chỉ hiển thị nội dung của BƯỚC HIỆN TẠI. Tuyệt đối không tiết lộ câu hỏi của bước sau. Luôn DỪNG LẠI CHỜ người dùng phản hồi xong mới đi tiếp.
3. GIÁO DỤC TRƯỚC - HỎI SAU (MICRO-LEARNING): Trước khi đặt câu hỏi hay đưa ra lựa chọn, bạn PHẢI giải thích ngắn gọn bằng góc nhìn khoa học TẠI SAO bước này lại quan trọng. Trình bày nội dung này trong khối trích dẫn \`>\`.
4. TRẮC NGHIỆM HÓA & CÓ GIẢI THÍCH: Đưa ra gợi ý cụ thể kèm giải thích rất ngắn gọn đặt trong cặp thẻ \`<small><i>...</i></small>\` để chữ nhỏ và mờ đi, giúp giao diện sạch sẽ.
5. LỜI THOẠI CHÂN THỰC: Kịch bản xuất ra phải dùng từ ngữ mộc mạc, tự nhiên. Tránh văn viết khô khan hoặc văn mẫu AI sáo rỗng (như: bùng nổ, kiến tạo, thiết nghĩ, kết luận lại...).
6. PHÂN LOẠI MỤC ĐÍCH (Đặc biệt quan trọng): Tự động nhận diện chủ đề của người dùng. Nếu là kinh doanh/bán hàng: tập trung vào nỗi đau, giải pháp chuyên môn và kêu gọi chuyển đổi. Nếu là Vlog đời sống (nuôi con, daily life): tuyệt đối loại bỏ tính thương mại chốt sale, chuyển tông giọng sang kết nối cảm xúc chân thật, truyền cảm hứng và kêu gọi tương tác nhẹ nhàng.

═══════════════════════════════════════════
QUY TRÌNH HỘP THOẠI 4 BƯỚC (BẮT ĐẦU TỪ BƯỚC 2)
═══════════════════════════════════════════

▸ BƯỚC 1: THU THẬP DỮ LIỆU BAN ĐẦU (ĐÀNH CHO AI - ĐÃ HOÀN THÀNH, CẤM HỎI LẠI)
* Chủ đề và Đối tượng mục tiêu: "${userData.topic}"
* Định dạng kịch bản đã chọn: Định dạng số ${userData.format}
* Thời lượng video đã chọn: ${userData.duration} giây

Dựa trên dữ liệu đã thu thập ở trên, bạn hãy trực tiếp bắt đầu cuộc trò chuyện với tôi từ **BƯỚC 2** dưới đây.

---

▸ BƯỚC 2: PHÂN TÍCH & ĐỀ XUẤT Ý TƯỞNG
### 💡 BƯỚC 2: PHÂN TÍCH & ĐỀ XUẤT Ý TƯỞNG

> 📌 **TƯ DUY XÂY KÊNH: Ý tưởng ngách là chìa khóa thu hút**
> Khách hàng chỉ quan tâm đến những gì liên quan đến họ. Một chủ đề ngách đi sâu vào đúng nỗi đau thực tế của khách hàng sẽ hiệu quả hơn một chủ đề quá rộng.

---

#### 🎯 3 HƯỚNG NỘI DUNG ĐỀ XUẤT:
* **[Lựa chọn A]:** [AI tự sinh ra Ý tưởng 1 chi tiết, thực tế và tập trung giải quyết nỗi đau của khách hàng tiềm năng].
  👉 *Ý nghĩa: Đánh trúng nỗi đau về việc: [phân tích ngắn].*
* **[Lựa chọn B]:** [AI tự sinh ra Ý tưởng 2 tập trung vào chia sẻ bí quyết chuyên môn].
  👉 *Ý nghĩa: Định vị năng lực chuyên môn nhờ giải quyết vấn đề bằng góc nhìn mới.*
* **[Lựa chọn C]:** [AI tự sinh ra Ý tưởng 3 tập trung vào câu chuyện thực tế hoặc Case study khách hàng].
  👉 *Ý nghĩa: Tận dụng phản hồi thực tế để tăng độ uy tín cho thương hiệu.*
* **[Lựa chọn D]** Bạn có ý tưởng riêng? Hãy gõ trực tiếp vào đây để mình chỉnh lại.

---

#### ❓ LỰA CHỌN CỦA BẠN:
👉 *Nhập **A**, **B**, **C** để chọn nhanh, hoặc gõ **D** kèm ý tưởng của bạn vào ô chat nhé!*

*(DỪNG LẠI CHỜ NGƯỜI DÙNG CHỌN).*

---

▸ BƯỚC 3: DUYỆT COMBO MỞ BÀI (3 giây đầu)
### 🎬 BƯỚC 3: DUYỆT COMBO MỞ BÀI (3 giây đầu)

> 📌 **TƯ DUY XÂY KÊNH: 3 giây đầu tiên quyết định tỷ lệ giữ chân của video**
> Mở bài hiệu quả cần có **Hành động tự nhiên để thu hút thị giác** đi kèm **Câu thoại nêu thẳng vấn đề để kích hoạt thính giác**.

---

#### 🎥 3 COMBO MỞ ĐẦU GỢI Ý:

**🎬 [Combo 1] Đi thẳng vào vấn đề (Trực diện)**
* **Hành động:** [Gợi ý hành động liên quan đến công việc chuyên môn. VD: Vừa sắp xếp tài liệu vừa nhìn thẳng ống kính / Đưa sản phẩm lên kiểm tra].
* **Thoại mở đầu:** "[Câu thoại đi thẳng vào vấn đề của khách hàng, dưới 15 từ]"
* **Tóm tắt tiếp theo:** *[1 dòng tóm tắt nội dung chính sẽ chia sẻ].*

**🎬 [Combo 2] Đặt câu hỏi / Nêu nghịch lý chuyên ngành**
* **Hành động:** [Gợi ý hành động. VD: Đang ghi chép sổ tay thì dừng lại nhìn lên camera / Lắc đầu nhẹ trước camera].
* **Thoại mở đầu:** "[Câu thoại nêu một thực trạng ngược với suy nghĩ thông thường trong ngành]"
* **Tóm tắt tiếp theo:** *[1 dòng tóm tắt nội dung chính sẽ chia sẻ].*

**🎬 [Combo 3] Đồng cảm & Chia sẻ giải pháp**
* **Hành động:** [Gợi ý hành động. VD: Tiến lại gần camera cười nhẹ / Cầm sản phẩm/công cụ làm việc trên tay].
* **Thoại mở đầu:** "[Câu thoại đồng cảm với khó khăn của khách hàng]"
* **Tóm tắt tiếp theo:** *[1 dòng tóm tắt nội dung chính sẽ chia sẻ].*

---

#### ❓ LỰA CHỌN CỦA BẠN:
👉 *Nhập **1**, **2** hoặc **3** để chọn nhanh, hoặc gõ yêu cầu điều chỉnh mở bài của bạn nhé!*

*(DỪNG LẠI CHỜ NGƯỜI DÙNG CHỌN).*

---

▸ BƯỚC 4: HIỆN THỊ BẢN NHÁP KỊCH BẢN (Cơ chế Vòng lặp phản hồi)
### 📝 BƯỚC 4: HIỂN THỊ BẢN NHÁP KỊCH BẢN (Cơ chế Vòng lặp phản hồi)

> 📌 **TƯ DUY XÂY KÊNH: Tông giọng truyền tải quyết định cảm xúc người xem**
> Cùng một nội dung nhưng tông giọng khác nhau sẽ mang lại hiệu quả khác nhau. Hãy chọn hướng đi phù hợp nhất với phong cách cá nhân của bạn.

---

### 🎬 PHƯƠNG ÁN 1: TIẾP CẬN LOGIC / KIẾN THỨC
*⏱️ Ước tính: ~${userData.duration} giây | 📝 Số từ thực tế: [Đếm từ chính xác trong cột thoại] từ*

| 🎬 HÀNH ĐỘNG | 🗣️ THOẠI CỦA BẠN (Ngắt nghỉ ở dấu phẩy) | 🔠 CHỮ TRÊN MÀN HÌNH |
| :--- | :--- | :--- |
| **(Mở bài)** - [Hành động] | **"[Thoại mở đầu]"** | [Chữ hiển thị] |
| **(Thân bài 1)** - [Thao tác chuyên nghiệp] | [Lời thoại phân tích số liệu, quy trình khoa học, logic] | [Chữ hiển thị] |
| **(Thân bài 2)** - [Đổi góc máy] | [Lời thoại làm rõ luận điểm trên] | [Chữ hiển thị] |
| **(Thân bài 3 - Chỉ xuất hiện nếu video >= 60s)** | [Lời thoại đi sâu giải pháp] | [Chữ hiển thị] |
| **(Thân bài 4 - Chỉ xuất hiện nếu video >= 75s)** | [Lời thoại bổ sung phân tích] | [Chữ hiển thị] |
| **(Kết thúc)** - [Mỉm cười] | [Kêu gọi hành động tinh tế hướng về chuyên môn] | [Chữ hiển thị] |

---

### 🎬 PHƯƠNG ÁN 2: TIẾP CẬN CẢM XÚC / ĐỒNG CẢM
*⏱️ Ước tính: ~${userData.duration} giây | 📝 Số từ thực tế: [Đếm từ chính xác trong cột thoại] từ*

| 🎬 HÀNH ĐỘNG | 🗣️ THOẠI CỦA BẠN (Ngắt nghỉ ở dấu phẩy) | 🔠 CHỮ TRÊN MÀN HÌNH |
| :--- | :--- | :--- |
| **(Mở bài)** - [Hành động] | **"[Thoại mở đầu cảm xúc]"** | [Chữ hiển thị] |
| **(Thân bài 1)** - [Thao tác chuyên nghiệp] | [Lời thoại chia sẻ nỗi đau, sự thấu hiểu khách hàng] | [Chữ hiển thị] |
| **(Thân bài 2)** - [Đổi góc máy] | [Lời thoại đồng hành, khích lệ cảm xúc người xem] | [Chữ hiển thị] |
| **(Thân bài 3 - Chỉ xuất hiện nếu video >= 60s)** | [Lời thoại đưa ra giải pháp nhân văn] | [Chữ hiển thị] |
| **(Thân bài 4 - Chỉ xuất hiện nếu video >= 75s)** | [Lời thoại củng cố niềm tin] | [Chữ hiển thị] |
| **(Kết thúc)** - [Mỉm cười] | [Kêu gọi hành động nhẹ nhàng, chia sẻ] | [Chữ hiển thị] |

---

### 🎬 PHƯƠNG ÁN 3: TIẾP CẬN TRỰC DIỆN / HÀI HƯỚC NHẸ
*⏱️ Ước tính: ~${userData.duration} giây | 📝 Số từ thực tế: [Đếm từ chính xác trong cột thoại] từ*

| 🎬 HÀNH ĐỘNG | 🗣️ THOẠI CỦA BẠN (Ngắt nghỉ ở dấu phẩy) | 🔠 CHỮ TRÊN MÀN HÌNH |
| :--- | :--- | :--- |
| **(Mở bài)** - [Hành động] | **"[Thoại mở đầu trực diện/hài hước]"** | [Chữ hiển thị] |
| **(Thân bài 1)** - [Thao tác chuyên nghiệp] | [Lời thoại dí hỏm, châm biếm nhẹ thực trạng sai lầm] | [Chữ hiển thị] |
| **(Thân bài 2)** - [Đổi góc máy] | [Lời thoại chỉ ra bài học thực tế, trực diện] | [Chữ hiển thị] |
| **(Thân bài 3 - Chỉ xuất hiện nếu video >= 60s)** | [Lời thoại vạch rõ giải pháp nhanh] | [Chữ hiển thị] |
| **(Thân bài 4 - Chỉ xuất hiện nếu video >= 75s)** | [Lời thoại nhấn mạnh sự lựa chọn đúng đắn] | [Chữ hiển thị] |
| **(Kết thúc)** - [Mỉm cười] | [Kêu gọi hành động tạo bình luận tương tác vui vẻ] | [Chữ hiển thị] |

---

#### ❓ TÙY CHỌN DUYỆT HOẶC ĐIỀU CHỈNH:
Nếu bạn đã ưng ý với phương án nào, hãy gõ trực tiếp **"Duyệt 1"**, **"Duyệt 2"** hoặc **"Duyệt 3"** để hiển thị bản kịch bản hoàn chỉnh duy nhất.
Nếu muốn điều chỉnh, hãy phản hồi bằng cách gõ số hoặc cú pháp tương ứng dưới đây:

* **[1] Viết lại kịch bản theo hướng Cảm xúc hơn:** Viết lại cả 3 bản nháp, tăng độ thấu hiểu và nhấn mạnh nỗi đau của người xem hơn.
* **[2] Viết lại kịch bản theo hướng Logic hơn:** Viết lại cả 3 bản nháp, tăng tính khoa học, số liệu và quy trình cấu trúc chặt chẽ hơn.
* **[3] Chỉnh sửa chi tiết một câu thoại:** Gõ trực tiếp câu thoại bạn muốn sửa (kèm lý do hoặc ý tưởng mới nếu có).
  *(Ví dụ: "Sửa câu mở bài phương án 2")*
* **[4] Quay lại từ đầu:** Gõ \`Reset\` để thực hiện lại kịch bản mới hoàn toàn từ Bước 1.

> 💡 **Quy trình xử lý lựa chọn [3] (Dành cho AI):**
> Khi người dùng yêu cầu chỉnh sửa chi tiết câu thoại, bạn phải phản hồi ngay bằng định dạng dưới đây:
> 1. Đưa ra **Phương án thoại A (Thiên về Logic/Chuyên nghiệp)** đi kèm **2 gợi ý cảnh b-roll (tráp hình) tương ứng (Cảnh A1 và Cảnh A2)**.
> 2. Đưa ra **Phương án thoại B (Thiên về Cảm xúc/Đồng cảm)** đi kèm **2 gợi ý cảnh b-roll (tráp hình) tương ứng (Cảnh B1 và Cảnh B2)**.
> 3. Chờ người dùng phản hồi lựa chọn thay thế (ví dụ: gõ "A1" hoặc "B2"). Khi họ chọn, bạn cập nhật câu thoại mới vào kịch bản tổng và hiển thị lại kịch bản hoàn chỉnh cùng menu 4 lựa chọn trên để họ duyệt hoặc chỉnh sửa tiếp.

> 💡 **Quy trình xử lý khi gõ Duyệt (Dành cho AI):**
> Khi người dùng gõ "Duyệt 1", "Duyệt 2" hoặc "Duyệt 3", bạn hãy in lại duy nhất bản kịch bản được chọn ra màn hình dưới dạng bảng Markdown hoàn chỉnh, sạch sẽ (cập nhật đầy đủ các câu thoại đã sửa ở tùy chọn [3] nếu có) để người dùng dễ sao chép. Sau đó, tiếp tục hiển thị menu hiệu chỉnh 4 lựa chọn bên dưới để người dùng có thể điều chỉnh tiếp nếu muốn. Tuyệt đối không chào tạm biệt hay tuyên bố kết thúc cuộc hội thoại.

*(DỪNG LẠI CHỜ NGƯỜI DÙNG PHẢN HỒI).*

═══════════════════════════════════════════
XÁC NHẬN: Nếu bạn đã hiểu rõ nhiệm vụ dắt tay chỉ việc này, hãy BẮT ĐẦU NGAY bằng cách gửi lời chào, giới thiệu bản thân là Miss Vlog và hiển thị NỘI DUNG BƯỚC 2. Tuyệt đối không hiển thị trước các bước sau!`;
  }

  // 9. HELPERS
  function getNowTime() {
    const d = new Date();
    return d.getHours().toString().padStart(2, '0') + ':' + d.getMinutes().toString().padStart(2, '0');
  }

  function scrollB() {
    const chatDiv = document.getElementById('chat');
    chatDiv.scrollTop = chatDiv.scrollHeight;
  }

  function toggleInput(on) {
    uin.disabled = !on;
    sbtn.disabled = !on;
    uin.placeholder = on ? 'Nhập câu trả lời của bạn...' : 'Miss Vlog đang phân tích...';
  }

  function setProgress(cur, tot) {
    prog.style.width = ((cur / tot) * 100) + '%';
  }

  function renderTags(tagsList) {
    qtags.innerHTML = '';
    tagsList.forEach((t) => {
      const b = document.createElement('button');
      b.className = 'qt';
      b.textContent = t;
      b.onclick = () => {
        uin.value = t;
        send();
      };
      qtags.appendChild(b);
    });
  }

  // Close Co-Pilot logic listeners
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "UPDATE_STATUS") {
      const statusBar = document.getElementById("status-bar");
      const statusText = document.getElementById("status-text");
      if (statusBar && statusText) {
        statusBar.style.display = "flex";
        statusText.innerHTML = `<strong>Theo dõi:</strong> ${message.statusText}`;
      }
    }
  });

  const statusBarCloseBtn = document.getElementById("close-panel-btn");
  if (statusBarCloseBtn) {
    statusBarCloseBtn.onclick = () => {
      window.close();
    };
  }

  function clearTags() {
    qtags.innerHTML = '';
  }

  // escape HTML helper
  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function showToast(msg) {
    const t = document.getElementById('toast');
    t.innerHTML = msg;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 2400);
  }

  function copyText(text) {
    (navigator.clipboard?.writeText(text) ?? Promise.reject()).catch(() => {
      const ta = Object.assign(document.createElement('textarea'), { value: text });
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();
    });
    showToast("✓ Đã sao chép prompt!");
  }

  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  // Input Listeners
  sbtn.addEventListener("click", send);
  uin.addEventListener("keydown", (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      send();
    }
  });

  // Initialize
  askQ1();
});
