// GIBI AI Studio - Director Dashboard Sidepanel Controller

const MEMORY_PROMPTS = {
  '1': `Tôi muốn làm một bộ phim ngắn về "Bữa cơm bếp củi Mẹ nấu ngày đông lạnh". Ngày đó gia đình tôi tuy nghèo khó nhưng vô cùng ấm áp, gian bếp nhỏ bập bùng ánh lửa, khói tỏa nghi ngút và mâm cơm nóng hổi do tay Mẹ nấu. Miss GIBI hãy giúp tôi thiết kế bối cảnh gian bếp cổ điển tràn ngập hoài niệm, tạo cảm giác vô cùng ấm cúng (cozy) theo phong cách Studio Ghibli nhé!`,
  '2': `Tôi muốn làm một bộ phim ngắn về "Chiếc xe đạp cọc cạch Ba chở qua cơn mưa". Đó là ký ức vô giá về người Ba vất vả thầm lặng chở tôi đi học dưới trời mưa tầm tã. Miss GIBI hãy giúp tôi thiết kế khung cảnh cơn mưa mùa hạ tươi mát, nước mưa gột rửa phố xá và bóng lưng ấm áp của Ba theo phong cách hoạt hình Ghibli nhiều xúc cảm nhé!`,
  '3': `Tôi muốn làm một bộ phim ngắn về "Ký ức góc sân quê bình yên bên Ông Bà". Đó là khoảng thời gian bình yên nhất đời tôi dưới hiên nhà ngói đỏ, giàn mướp xanh và ánh nắng chiều tà (golden hour) rực rỡ. Miss GIBI hãy giúp tôi tái hiện lại góc sân quê và nụ cười hiền hậu của Ông Bà theo nét vẽ hoài niệm Studio Ghibli nhé!`,
  '4': `Tôi muốn làm một bộ phim ngắn về "Mối tình đầu năm tháng cấp 3 dưới tàng cây". Đó là những rung động trong trẻo của tuổi học trò dưới tán phượng vĩ rực rỡ và bóng mát tàng cây mái trường. Miss GIBI hãy giúp tôi thiết kế thước phim thanh xuân rực rỡ mang nét vẽ cel-shaded đặc trưng của anime Ghibli nhé!`,
  '5': `Tôi muốn làm một bộ phim ngắn về "Căn phòng trọ 10m2 những ngày đầu lập nghiệp". Ngày đó tôi rất vất vả nhưng đầy hoài bão. Tôi có một vài bức ảnh chụp căn phòng lộn xộn ngày xưa. Miss GIBI hãy giúp tôi thiết kế bối cảnh căn phòng này theo phong cách Lofi ấm áp của Ghibli, thể hiện sự nỗ lực làm việc giữa đêm khuya nhé!`,
  '6': `Tôi muốn làm một bộ phim ngắn về "Hồi sinh người bạn thú cưng tuổi thơ đã xa". Đó là chú cưng thân thiết đã từng gắn bó suốt những năm tháng tuổi thơ của tôi. Miss GIBI hãy giúp tôi hồi sinh hình ảnh chú cưng đang chạy nhảy tung tăng trên cánh đồng cỏ xanh ngút ngàn dưới bầu trời mây trắng cổ tích Ghibli nhé!`,
  '7': `Tôi muốn làm một bộ phim ngắn về "Gặp lại đứa trẻ bên trong và ước mơ thuở bé". Thuở bé tôi luôn mơ ước được tự do bay lượn trên bầu trời rộng lớn. Miss GIBI hãy dùng thế mạnh kỳ ảo (Magic Realism) của Ghibli để giúp tôi vẽ lại hình ảnh đứa trẻ 5 tuổi đang cưỡi mây ngắm nhìn thế giới thần tiên nhé!`,
  '8': `Tôi muốn kể về khoảnh khắc dũng cảm nhất đời mình: Nộp đơn nghỉ việc để đi theo đam mê. Tôi chỉ có ảnh đang ngồi làm việc mệt mỏi. Hãy tạo sự tương phản Ghibli: Từ góc văn phòng xám xịt chật chội, chuyển cảnh sang lúc tôi bước ra ngoài, ánh nắng hoàng hoàng rực rỡ rọi vào nụ cười tự do và đầy hy vọng của tôi.`,
  '9': `Tôi đang trải qua hành trình thức tỉnh tâm linh và thiền định. Từ ảnh chân dung của tôi, hãy đặt tôi vào một không gian Ghibli siêu thực: Ngồi thiền dưới một cây cổ thụ khổng lồ, mặt hồ phản chiếu bầu trời sao lấp lánh, đom đóm bay quanh, mang lại cảm giác bình yên và tĩnh lặng tuyệt đối.`,
  '10': `Hành trình đứng dậy sau đổ vỡ và học cách yêu lại bản thân. Hãy dùng ảnh cũ của tôi tạo một mạch truyện Ghibli: Bắt đầu bằng bối cảnh trời mưa u ám, sau đó tôi dũng cảm mở toang cửa sổ, ánh nắng rực rỡ chiếu vào khuôn mặt tự tin, xung quanh hoa cỏ đâm chồi nảy lộc tượng trưng cho sự tái sinh.`,
  '11': `Một chuyến đi thanh xuân một mình đã thay đổi thế giới quan của tôi. Tôi chỉ có vài bức ảnh chụp vội. Hãy đưa tôi vào một khung cảnh Ghibli hoành tráng: Tôi đang ngồi trên một chuyến tàu vắng vẻ nhìn ra biển, hoặc đeo balo đứng trên một ngọn đồi cỏ xanh ngắt, gió thổi tung vạt áo, mang cảm giác cô đơn nhưng tự do.`,
  '12': `Hành trình hiện thực hóa giấc mơ mở một tiệm nhỏ (cà phê/hoa/bánh) của riêng tôi. Hãy biến những bức ảnh lúc tôi vất vả dọn dẹp mặt bằng ngổn ngang thành một cửa tiệm bằng gỗ phong cách Ghibli cực kỳ ấm cúng, xinh xắn, tràn ngập ánh nắng ban mai và cây cỏ xanh mướt.`
};

const buildMegaPrompt = (userName = 'bạn') => `BẠN LÀ MISS GIBI — TRỢ LÝ ĐẠO DIỄN HOẠT HÌNH AI (STUDIO GHIBLI STYLE) CỦA ${userName.toUpperCase()}.
Nhiệm vụ: Dẫn dắt ${userName} qua từng bước: Khóa Mặt Đa Góc Độ (Turnaround Sheet) -> Bảng Storyboard 16 Ô (Bảng Markdown + Ảnh Lưới 4x4) -> Sản xuất từng Frame một (TỪ FRAME 1 ĐẾN FRAME 16).
Phong cách MẶC ĐỊNH: "Studio Ghibli animation style, 2D anime, masterpiece, Hayao Miyazaki aesthetic, cel-shaded, cinematic colors".

🛑 LỆNH HỆ THỐNG CỐT LÕI (CỖ MÁY TRẠNG THÁI):

1. QUY TẮC GIẢ ĐỊNH LUÔN LUÔN HƯỚNG DẪN TẠO ẢNH CHO NGƯỜI MỚI (BẮT BUỘC Ở MỌI GIAI ĐOẠN 1, 2, 3):
   - Ở BẤT KỲ GIAI ĐOẠN NÀO (Giai đoạn 1 Model Sheet, Giai đoạn 2 Storyboard 4x4 Grid, Giai đoạn 3 Frame Production), BẮT BUỘC giả định rằng giao diện chat có thể không tự xuất được ảnh.
   - Luôn luôn in HƯỚNG DẪN 3 BƯỚC CHI TIẾT: Copy prompt ở đâu (nút Copy Prompt), bấm link Google Flow nào (👉 https://labs.google/fx/tools/flow), dán vào đâu và tải ảnh về máy ra sao!

2. QUY TẮC CẤM IN MÃ NỘI BỘ / LINK GIẢ MẠO:
   - TUYỆT ĐỐI KHÔNG in các đường link dạng http://googleusercontent.com/image_generation_content/... hoặc mã nội bộ trong chat. Chỉ in văn bản Tiếng Việt hướng dẫn người dùng và Code Block chứa Prompt Tiếng Anh.

--- BẮT ĐẦU QUY TRÌNH CHI TIẾT ---

[GIAI ĐOẠN 0: KHỞI TẠO DỰ ÁN]
Gửi sơ đồ quy trình sau:
=============================================================
[ 🎬 QUY TRÌNH GHIBLI AI (SẢN XUẤT TỪNG FRAME) ]
=============================================================
[PRE-PRODUCTION]
 1. Nạp Kịch bản + Chọn Tỷ Lệ + Tải Ảnh Chân Dung.
       ↓
 2. Vẽ 'Bảng Chân Dung Đa Góc Độ' (Chính diện, Nghiêng, Profile, Trên xuống)
    -> KHÓA THẦN THÁI NHÂN VẬT Ó MỌI GÓC CẢNH QUAY.
       ↓
 3. Chốt Bảng Storyboard 16 Ô (Bảng Markdown + Ảnh Lưới 4x4).
=============================================================
[PRODUCTION - SẢN XUẤT TỪNG FRAME MỘT]
 4. AI tự động tạo từng Frame từ Frame 1 -> Frame 16.
    Mỗi Frame bao gồm HƯỚNG DẪN 3 BƯỚC CHI TIẾT:
    - 📸 Bước 1: Prompt Ảnh Tĩnh + Hướng dẫn vẽ & tải ảnh về máy.
    - 🎬 Bước 2: Prompt Video Veo 3 + Link Google Flow + Hướng dẫn đính kèm ảnh gốc.
    - ❓ Bước 3: Xác nhận [Gõ 1] để sang Frame tiếp theo HOẶC [Gõ 2 + Đính kèm ảnh bối cảnh mới / vibe không gian] để sửa lại Frame.
=============================================================

Xác nhận ngắn gọn và yêu cầu:
"Chào ${userName}! Miss GIBI đã ghi nhận đầy đủ kịch bản cùng Tỷ lệ khung hình của ${userName}.

📸 BƯỚC TIẾP THEO: **Vui lòng đính kèm 1-3 bức ảnh chân dung CẬN MẶT rõ nét của ${userName} vào khung chat này** để Miss GIBI vẽ 'Bảng Chân Dung Đa Góc Độ' và chốt nét mặt cho nhân vật hoạt hình Ghibli của ${userName} nhé!"

[GIAI ĐOẠN 1: ÉP KHUÔN ĐA GÓC ĐỘ - BẢNG MODEL SHEET]
(Khi người dùng đính kèm 1-3 ảnh chân dung).
1. Phân tích nét mặt cận cảnh thành \`[FINAL_FACE_JSON]\`.
2. In nhãn rõ ràng: "📌 **PROMPT BẢNG CHÂN DUNG ĐA GÓC ĐỘ (MODEL SHEET TURNAROUND)**"
3. In 1 Code block: \`"Anime character model sheet turnaround, multiple camera angles of the same character in one frame (front view, 3/4 view, side profile view, high angle view), Studio Ghibli style, featuring [FINAL_FACE_JSON], wearing simple t-shirt, clean character reference design sheet. Aspect ratio: [Tỷ lệ]"\`.
4. Gọi \`generate_image\` ĐỂ VẼ 1 BẢNG CHÂN DUNG ĐA GÓC ĐỘ.
5. In HƯỚNG DẪN TẠO ẢNH BẢNG CHÂN DUNG (NẾU CHAT KHÔNG TỰ XUẤT ẢNH):
   "💡 **HƯỚNG DẪN TẠO ẢNH BẢNG CHÂN DUNG (NẾU CHAT KHÔNG TỰ HIỂN THỊ ẢNH):**
   - **Bước 1**: Bấm nút **'📋 Copy Prompt'** ở ô mã trên.
   - **Bước 2**: Bấm link này để mở Google Flow: 👉 https://labs.google/fx/tools/flow (hoặc ô Image của Gemini).
   - **Bước 3**: Dán prompt vừa copy vào để vẽ Bảng Chân Dung Đa Góc Độ và **tải bức ảnh vừa vẽ về máy tính** nhé!"
6. IN CÂU HỎI XÁC NHẬN:
"Nét mặt nhân vật đa góc độ này ổn chưa ${userName}?
- [Gõ 1]: Rất tuyệt! Chốt nét mặt đa góc này làm Hằng số.
- [Gõ 2]: Chưa giống! Đính kèm ảnh chân dung khác hoặc mô tả lại nét mặt mới.
- [Gõ 3]: Đổi bộ ảnh chân dung khác."

[GIAI ĐOẠN 2: BẢNG STORYBOARD 16 Ô (BẢNG MARKDOWN + ẢNH LƯỚI 4X4)]
1. Xuất BẢNG STORYBOARD 16 KHUNG HÌNH dạng bảng Markdown gồm 4 cột (Khung | Cảnh Quay & Hành Động | Câu Thoại | Giọng Điệu).
2. In nhãn: "📌 **PROMPT ẢNH LƯỚI STORYBOARD 4X4 (16 PANELS)**"
3. In Code block: \`"A 4x4 grid layout storyboard featuring 16 anime panels, Studio Ghibli style, featuring [FINAL_FACE_JSON], sequential cinematic scenes, masterpiece. Aspect ratio: [Tỷ lệ]"\`.
4. Gọi CÔNG CỤ VẼ ẢNH \`generate_image\` ĐỂ HIỂN THỊ ẢNH LƯỚI 4X4 MINH HỌA.
5. BẮT BUỘC In HƯỚNG DẪN TẠO ẢNH LƯỚI STORYBOARD 4X4 (NẾU CHAT KHÔNG TỰ XUẤT ẢNH):
   "💡 **HƯỚNG DẪN TẠO ẢNH LƯỚI STORYBOARD 4X4 (NẾU CHAT KHÔNG TỰ HIỂN THỊ ẢNH):**
   - **Bước 1**: Bấm nút **'📋 Copy Prompt'** ở ô mã trên.
   - **Bước 2**: Bấm link mở Google Flow: 👉 https://labs.google/fx/tools/flow (hoặc ô Image của Gemini).
   - **Bước 3**: Dán prompt vừa copy vào để vẽ Ảnh Lưới Storyboard 4x4 và **tải bức ảnh vừa vẽ về máy tính** để xem trước 16 khung hình nhé!"
6. IN CÂU HỎI XÁC NHẬN:
"Bảng Storyboard 16 Khung Hình & Ảnh Lưới 4x4 đã xong. 
- [Gõ 1]: Rất tuyệt! Bắt đầu sản xuất Frame 1.
- [Gõ 2]: Cần chỉnh sửa lại nội dung cảnh quay hoặc lời thoại."

[GIAI ĐOẠN 3: SẢN XUẤT CUỐN CHIẾU TỪNG FRAME (FRAME 1 ĐẾN FRAME 16)]
Tại mỗi Frame N (từ Frame 1 đến 16):

=============================================================
🎬 **SẢN XUẤT FRAME [N]/16: [Tên Cảnh Quay]**

Chào ${userName}, hãy làm theo 3 bước siêu đơn giản dưới đây để tạo Ảnh gốc & Video cho Frame [N] nhé:

---
📸 **BƯỚC 1: TẠO ẢNH TĨNH ANIME (LẤY HÌNH GỐC)**
1. **Bấm nút "📋 Copy Prompt Ảnh"** bên dưới để copy prompt vẽ ảnh nhân vật:
\`\`\`text
[Prompt Ảnh Tĩnh Frame N chứa [FINAL_FACE_JSON] + bối cảnh + Studio Ghibli style + aspect ratio]
\`\`\`
2. **Dán prompt vừa copy vào ô vẽ ảnh của Gemini (hoặc ô Image của Google Flow 👉 https://labs.google/fx/tools/flow)** để vẽ ảnh. Sau đó **Tải bức ảnh vừa vẽ về máy tính**.

---
🎬 **BƯỚC 2: TẠO VIDEO CHUYỂN ĐỘNG VEO 3**
1. **Bấm link này để mở Google Flow:** 👉 https://labs.google/fx/tools/flow
2. **Tải bức ảnh tĩnh vừa làm ở Bước 1 lên làm Ảnh Tham Chiếu (First Frame / Reference Image).**
3. **Bấm nút "🚀 Copy Prompt Video"** bên dưới để copy lệnh chuyển động:
\`\`\`text
[Prompt Video Frame N: Camera movement/zoom/pan + micro-actions]
\`\`\`
4. **Dán prompt chuyển động vào ô Video của Google Flow và bấm Tạo Video (Generate)!**

---
❓ **BƯỚC 3: XÁC NHẬN & TINH CHỈNH BỐI CẢNH / VIBE**
Bạn đã tạo xong Ảnh & Video cho Frame [N] chưa?
- **[Gõ 1]**: Đã xong! Chuyển sang sản xuất **Frame [N+1]**.
- **[Gõ 2]**: Chưa ưng! **Đính kèm thêm 1 ảnh bối cảnh mẫu** (hoặc gõ mô tả vibe/không gian xung quanh mong muốn) để Miss GIBI sửa lại không gian bối cảnh cho Frame [N] nhé!
=============================================================

(Lặp lại quy trình này đúng từng Frame một cho đến khi hoàn thành xong Frame 16!).

KÍCH HOẠT [GIAI ĐOẠN 0] NGAY BÂY GIỜ!`;

document.addEventListener('DOMContentLoaded', async () => {
  console.log('[GIBI AI] Director Dashboard Controller Loaded');

  // DOM Elements
  const inputUserName = document.getElementById('input-user-name');
  const inputScriptIdea = document.getElementById('input-script-idea');
  const btnStartPhase0 = document.getElementById('btn-start-phase-0');
  const btnResetProject = document.getElementById('btn-reset-project');
  const statusText = document.getElementById('status-text');
  const titleText = document.getElementById('title-text');
  const editNameBtn = document.getElementById('edit-name-btn');

  // Step Elements
  const stepView1 = document.getElementById('step-view-1');
  const stepView2 = document.getElementById('step-view-2');
  const stepView3 = document.getElementById('step-view-3');

  const btnNextStep1 = document.getElementById('btn-next-step-1');
  const btnBackStep2 = document.getElementById('btn-back-step-2');
  const btnNextStep2 = document.getElementById('btn-next-step-2');
  const btnBackStep3 = document.getElementById('btn-back-step-3');

  const stepDot1 = document.getElementById('step-dot-1');
  const stepDot2 = document.getElementById('step-dot-2');
  const stepDot3 = document.getElementById('step-dot-3');
  const stepLine1 = document.getElementById('step-line-1');
  const stepLine2 = document.getElementById('step-line-2');

  // Auto expand textarea height dynamically to fit full prompt text
  const autoExpandTextarea = (el) => {
    if (!el) return;
    el.style.height = '85px';
    const scrollH = el.scrollHeight;
    if (scrollH > 85) {
      el.style.height = Math.min(250, scrollH + 6) + 'px';
    } else {
      el.style.height = '85px';
    }
  };

  // Helper to update brand header text
  function updateBrandHeader(name) {
    if (!name || !name.trim()) {
      if (titleText) titleText.textContent = 'Miss GIBI';
    } else {
      if (titleText) titleText.textContent = `Miss GIBI của ${name.trim()}`;
    }
  }

  // Stepper Controller
  function goToStep(stepNumber) {
    stepView1.classList.add('hidden');
    stepView2.classList.add('hidden');
    stepView3.classList.add('hidden');

    stepDot1.classList.remove('active', 'completed');
    stepDot2.classList.remove('active', 'completed');
    stepDot3.classList.remove('active', 'completed');
    stepLine1.classList.remove('active');
    stepLine2.classList.remove('active');

    if (stepNumber === 1) {
      stepView1.classList.remove('hidden');
      stepDot1.classList.add('active');
      if (inputUserName) inputUserName.focus();
    } else if (stepNumber === 2) {
      stepView2.classList.remove('hidden');
      stepDot1.classList.add('completed');
      stepLine1.classList.add('active');
      stepDot2.classList.add('active');
    } else if (stepNumber === 3) {
      stepView3.classList.remove('hidden');
      stepDot1.classList.add('completed');
      stepLine1.classList.add('active');
      stepDot2.classList.add('completed');
      stepLine2.classList.add('active');
      stepDot3.classList.add('active');
      if (inputScriptIdea) {
        autoExpandTextarea(inputScriptIdea);
        inputScriptIdea.focus();
      }
    }
  }

  // Restore saved state
  const stored = await chrome.storage.local.get(['userName', 'scriptIdea', 'aspectRatio']);
  if (stored.userName) {
    if (inputUserName) inputUserName.value = stored.userName;
    updateBrandHeader(stored.userName);
  } else {
    updateBrandHeader('');
  }

  if (stored.scriptIdea && inputScriptIdea) {
    inputScriptIdea.value = stored.scriptIdea;
    setTimeout(() => autoExpandTextarea(inputScriptIdea), 100);
  }

  if (inputScriptIdea) {
    inputScriptIdea.addEventListener('input', () => autoExpandTextarea(inputScriptIdea));
  }

  if (stored.aspectRatio) {
    const radio = document.querySelector(`input[name="aspect-ratio"][value="${stored.aspectRatio}"]`);
    if (radio) {
      radio.checked = true;
      document.querySelectorAll('.radio-card').forEach((card) => card.classList.remove('active'));
      radio.closest('.radio-card')?.classList.add('active');
    }
  }

  // Radio cards toggle styling
  document.querySelectorAll('.radio-card').forEach((card) => {
    card.addEventListener('click', () => {
      document.querySelectorAll('.radio-card').forEach((c) => c.classList.remove('active'));
      card.classList.add('active');
      const radio = card.querySelector('input[type="radio"]');
      if (radio) radio.checked = true;
    });
  });

  // Emotional Memory Idea chips selection listener (Autofill Rich Personalized Prompts & Auto Expand Textarea)
  document.querySelectorAll('.idea-chip').forEach((chip) => {
    chip.addEventListener('click', () => {
      const ideaId = chip.getAttribute('data-idea-id');
      const richPrompt = MEMORY_PROMPTS[ideaId];
      if (richPrompt && inputScriptIdea) {
        inputScriptIdea.value = richPrompt;
        autoExpandTextarea(inputScriptIdea);
        inputScriptIdea.focus();
      }
    });
  });

  // Step 1 -> Next
  if (btnNextStep1) {
    btnNextStep1.addEventListener('click', () => {
      const name = inputUserName ? inputUserName.value.trim() : '';
      if (!name) {
        alert('Vui lòng nhập tên của bạn để tiếp tục!');
        if (inputUserName) inputUserName.focus();
        return;
      }
      chrome.storage.local.set({ userName: name });
      updateBrandHeader(name);
      goToStep(2);
    });
  }

  // Enter key on Step 1 Name input
  if (inputUserName) {
    inputUserName.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        btnNextStep1.click();
      }
    });
    inputUserName.addEventListener('input', (e) => {
      updateBrandHeader(e.target.value.trim());
    });
  }

  // Step 2 -> Back & Next
  if (btnBackStep2) {
    btnBackStep2.addEventListener('click', () => goToStep(1));
  }
  if (btnNextStep2) {
    btnNextStep2.addEventListener('click', () => goToStep(3));
  }

  // Step 3 -> Back
  if (btnBackStep3) {
    btnBackStep3.addEventListener('click', () => goToStep(2));
  }

  // Edit name pencil click listener
  if (editNameBtn) {
    editNameBtn.addEventListener('click', () => {
      goToStep(1);
    });
  }

  // Reset Project
  btnResetProject.addEventListener('click', async () => {
    if (confirm('Bạn có chắc chắn muốn làm mới Dự án Gibi AI không?')) {
      await chrome.storage.local.clear();
      if (inputScriptIdea) inputScriptIdea.value = '';
      if (inputUserName) inputUserName.value = '';
      window.location.reload();
    }
  });

  // Smart Helper: Auto-detect, switch to, or create Gemini Tab automatically with GUARANTEED AUTO-RETRY!
  async function sendToGemini(action, payload = {}) {
    const tabs = await chrome.tabs.query({ currentWindow: true });
    let geminiTab = tabs.find((t) => t.active && t.url && t.url.includes('gemini.google.com'));

    if (!geminiTab) {
      geminiTab = tabs.find((t) => t.url && t.url.includes('gemini.google.com'));
      if (geminiTab) {
        await chrome.tabs.update(geminiTab.id, { active: true });
      }
    }

    if (!geminiTab) {
      console.log('[GIBI AI] No Gemini tab open, creating new tab automatically...');
      geminiTab = await chrome.tabs.create({ url: 'https://gemini.google.com', active: true });

      await new Promise((resolve) => {
        const listener = (tabId, changeInfo) => {
          if (tabId === geminiTab.id && changeInfo.status === 'complete') {
            chrome.tabs.onUpdated.removeListener(listener);
            resolve();
          }
        };
        chrome.tabs.onUpdated.addListener(listener);
        setTimeout(resolve, 8000);
      });
    }

    try {
      const response = await chrome.tabs.sendMessage(geminiTab.id, { action, ...payload });
      if (response && response.success) return response;
    } catch (err) {
      console.warn('[GIBI AI] Content script not responding initially, injecting content script...', err);
    }

    try {
      await chrome.scripting.executeScript({
        target: { tabId: geminiTab.id },
        files: ['scripts/content-gemini.js']
      });
    } catch (scriptErr) {
      console.error('[GIBI AI] Failed to execute content script:', scriptErr);
    }

    for (let attempt = 1; attempt <= 5; attempt++) {
      await new Promise((resolve) => setTimeout(resolve, attempt * 400));
      try {
        const response = await chrome.tabs.sendMessage(geminiTab.id, { action, ...payload });
        if (response && response.success) {
          console.log(`[GIBI AI] Successfully communicated with Gemini on attempt ${attempt}`);
          return response;
        }
      } catch (retryErr) {
        console.warn(`[GIBI AI] Retry attempt ${attempt} failed, retrying...`, retryErr);
      }
    }

    if (statusText) statusText.innerText = '✨ Đã kết nối với Gemini! Hãy chờ ô chat phản hồi.';
    return null;
  }

  // Phase 0: Start Project Action (Step 3 Submit)
  if (btnStartPhase0) {
    btnStartPhase0.addEventListener('click', async () => {
      const scriptIdea = inputScriptIdea.value.trim();
      if (!scriptIdea) {
        if (statusText) statusText.innerText = '⚠️ Vui lòng nhập Ý tưởng kịch bản trước!';
        alert('Vui lòng nhập Ý tưởng kịch bản trước!');
        if (inputScriptIdea) inputScriptIdea.focus();
        return;
      }

      const userName = (inputUserName ? inputUserName.value.trim() : '') || 'bạn';
      const selectedRatio = document.querySelector('input[name="aspect-ratio"]:checked')?.value || '16:9';

      await chrome.storage.local.set({ userName, scriptIdea, aspectRatio: selectedRatio });
      updateBrandHeader(userName !== 'bạn' ? userName : '');

      const fullMegaPrompt = buildMegaPrompt(userName);

      const fullInjectionPrompt = `⚠️ [CẤU HÌNH XƯNG HÔ THỜI GIAN THỰC]:
Bạn là Miss GIBI — chuyên gia đồng hành đạo diễn phim hoạt hình 2D phong cách Studio Ghibli của ${userName}. Hãy tự xưng là "Miss GIBI" và gọi người dùng là "${userName}" trong toàn bộ quá trình sản xuất phim nhé!

${fullMegaPrompt}

THÔNG TIN KỊCH BẢN ĐÃ CUNG CẤP TỪ BẢNG ĐIỀU KHIỂN (TUYỆT ĐỐI KHÔNG HỎI LẠI ĐIỀU NÀY):
1. Ý tưởng/Kịch bản: "${scriptIdea}"
2. Tỷ lệ video: Aspect ratio ${selectedRatio}

Hãy gửi sơ đồ quy trình, xác nhận đã nhận được kịch bản trên, và HỎI DUY NHẤT 1 VIỆC: Yêu cầu ${userName} đính kèm 1-3 ảnh chân dung cận mặt để tạo 'Bảng Chân Dung Đa Góc Độ' nhé!`;

      if (statusText) statusText.innerText = '⏳ Đang tự động gửi kịch bản sang Gemini Chat...';

      const res = await sendToGemini('INJECT_PROMPT', { promptText: fullInjectionPrompt });
      if (res && res.success) {
        if (statusText) statusText.innerText = `✨ Đã gửi kịch bản! Hãy đính kèm ảnh chân dung ở khung chat nhé ${userName}.`;
      } else {
        if (statusText) statusText.innerText = `✨ Đã chuyển kịch bản sang Gemini! Kiểm tra khung chat nhé ${userName}.`;
      }
    });
  }

  // Initialize view at Step 1 or Step 3 if name already filled
  if (stored.userName) {
    goToStep(3);
  } else {
    goToStep(1);
  }
});
